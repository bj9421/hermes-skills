---
name: taiwan-stock-sqlite-pipeline
description: Build a SQLite-based pipeline for downloading Taiwan stock daily price data with rate limit handling and incremental updates.
version: 1.1
author: Hermes Agent
---

# Taiwan Stock Daily Price Data Pipeline (SQLite)

This skill outlines a robust, rate-limit-friendly approach to download historical and daily Taiwan stock price data (TWSE & TPEX) into a SQLite database for analysis.

## Overview
- Data source: `twstock` Python library (wrapper for TWSE/TPEX APIs)
- Storage: SQLite database with table `daily_prices`
- Key concerns: Respect TWSE rate limits (~60 requests/minute for historical data), avoid IP bans, support incremental daily updates.
- Output: Queryable SQLite file usable via SQL, pandas, or any SQLite client.

## Prerequisites
- Python 3.8+
- Packages: `twstock`, `pandas`
- Optional: `openpyxl` for Excel export (not required)

Install:
```bash
pip install twstock pandas
```

## Database Schema
```sql
CREATE TABLE IF NOT EXISTS daily_prices (
    date TEXT NOT NULL,          -- YYYY-MM-DD
    stock_code TEXT NOT NULL,    -- e.g., 2330
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,              -- 成交股數 (張)
    turnover REAL,               -- 成交金額 (千元)
    transaction_count INTEGER,   -- 成交筆數 (note: renamed from 'transaction' to avoid SQL keyword)
    amplitude REAL,
    PRIMARY KEY (date, stock_code)
);
CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);
CREATE INDEX IF NOT EXISTS idx_date  ON daily_prices(date);
```

## Step‑by‑Step Procedure

### 1. Initialize DB (run once)
```python
import sqlite3
from pathlib import Path

def init_db(db_path: Path = Path("taiwan_stocks.db")):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS daily_prices (
            date TEXT NOT NULL,
            stock_code TEXT NOT NULL,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume INTEGER,
            turnover REAL,
            transaction_count INTEGER,
            amplitude REAL,
            PRIMARY KEY (date, stock_code)
        );
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);")
    conn.commit()
    conn.close()
```

### 2. Rate‑Limiter Wrapper
```python
import time

class TWSERateLimiter:
    def __init__(self, max_per_minute: int = 50):  # Conservative < 60 limit
        self.min_interval = 60.0 / max_per_minute
        self.last_request = 0.0
    def wait(self):
        elapsed = time.time() - self.last_request
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_request = time.time()
```

### 3. Download Single Stock (with retries)
```python
import requests
from twstock import Stock
from datetime import datetime

def fetch_stock_data(stock_code: str, limiter: TWSERateLimiter, start_year: int, start_month: int, max_retries: int = 3):
    """
    Fetch historical data for a single stock from a given start year/month to present.
    Returns list of dicts ready for SQLite upsert.
    """
    for attempt in range(max_retries):
        try:
            limiter.wait()
            stock = Stock(stock_code)
            data = stock.fetch_from(start_year, start_month)
            if not data:
                return []
            # Convert to list of dicts
            records = []
            for d in data:
                records.append({
                    "date": d.date.strftime("%Y-%m-%d"),
                    "stock_code": stock_code,
                    "open": float(d.open) if d.open is not None else None,
                    "high": float(d.high) if d.high is not None else None,
                    "low": float(d.low) if d.low is not None else None,
                    "close": float(d.close) if d.close is not None else None,
                    "volume": int(d.capacity) if d.capacity is not None else None,
                    "turnover": float(d.turnover) if d.turnover is not None else None,
                    "transaction_count": int(d.transaction) if d.transaction is not None else None,
                    "amplitude": float(getattr(d, "amplitude", None)) if getattr(d, "amplitude", None) is not None else None
                })
            return records
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                retry_after = int(e.response.headers.get("Retry-After", 60))
                time.sleep(retry_after * (attempt + 1))  # exponential backoff
                continue
            else:
                raise
        except Exception:
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)
    return []
```

### 4. Batch Upsert into SQLite
```python
def upsert_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cols = ", ".join(records[0].keys())
    placeholders = ", ".join(["?"] * len(records[0]))
    sql = f"""
        INSERT OR REPLACE INTO daily_prices ({cols})
        VALUES ({placeholders});
    """
    data = [tuple(r[c] for c in records[0].keys()) for r in records]
    cur.executemany(sql, data)
    conn.commit()
    return len(data)
```

### 5. Full Market Download (Historical Bootstrap)
```python
from twstock import twse, tpex
import time

def download_all_historical(db_path: Path = Path("taiwan_stocks.db"), start_year: int = 2000, start_month: int = 1):
    """
    Download historical data for all stocks from a fixed start date (e.g., 2000-01).
    Warning: This may take several hours depending on number of stocks and network speed.
    For regular updates, prefer the incremental daily update function.
    """
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    limiter = TWSERateLimiter(max_per_minute=50)

    # Update code lists once
    twse.update()
    tpex.update()
    # After update, twstock.codes contains all codes from both exchanges
    all_codes = {code: info for code, info in twstock.codes.items() if info.type == "股票"}

    total = len(all_codes)
    success = 0
    for idx, (code, info) in enumerate(all_codes.items(), start=1):
        try:
            records = fetch_stock_data(code, limiter, start_year, start_month)
            if records:
                inserted = upsert_records(conn, records)
                success += 1
                print(f"[{idx}/{total}] {code} ({info.name}): {inserted} records")
            else:
                print(f"[{idx}/{total}] {code}: No data")
        except Exception as e:
            print(f"[{idx}/{total}] {code}: Error - {e}")
        # Optional: progress logging every 50 stocks
        if idx % 50 == 0:
            print(f"  Progress: {idx}/{total} stocks processed")
    conn.close()
    print(f"Completed: {success}/{total} stocks processed")
```

### 6. Incremental Daily Update (Recommended for daily runs)
```python
from twstock import twse, tpex, Stock
from datetime import datetime

def download_today_only(db_path: Path = Path("taiwan_stocks.db")):
    """
    Download only today's trading data for all stocks.
    Ideal for daily automated runs (e.g., via cron after 15:30 TW time).
    """
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    limiter = TWSERateLimiter(max_per_minute=50)

    # Update code lists once
    twse.update()
    tpex.update()
    all_codes = {code: info for code, info in twstock.codes.items() if info.type == "股票"}

    today = datetime.now().date()
    processed = 0
    updated = 0
    for code, info in all_codes.items():
        try:
            limiter.wait()
            stock = Stock(stock_code=code)
            # Fetch from current month to get today's data
            data = stock.fetch_from(today.year, today.month)
            # Keep only today's record
            today_data = [d for d in data if d.date == today]
            if not today_data:
                # No trading today (e.g., holiday)
                continue
            records = [{
                "date": d.date.strftime("%Y-%m-%d"),
                "stock_code": code,
                "open": float(d.open) if d.open is not None else None,
                "high": float(d.high) if d.high is not None else None,
                "low": float(d.low) if d.low is not None else None,
                "close": float(d.close) if d.close is not None else None,
                "volume": int(d.capacity) if d.capacity is not None else None,
                "turnover": float(d.turnover) if d.turnover is not None else None,
                "transaction_count": int(d.transaction) if d.transaction is not None else None,
                "amplitude": float(getattr(d, "amplitude", None)) if getattr(d, "amplitude", None) is not None else None
            } for d in today_data]
            upsert_records(conn, records)
            updated += 1
        except Exception as e:
            print(f"Error for {code}: {e}")
        processed += 1
        if processed % 100 == 0:
            print(f"  Processed {processed}/{len(all_codes)} stocks...")
    conn.close()
    print(f"Finished. Updated {updated} stocks with today's data.")
```

## Rate‑Limit Guidelines
- **Historical data endpoint**: ~60 requests/minute (TWSE). \n  → Use `max_per_minute=50` in `TWSERateLimiter` to stay safely under.\n- **Intraday/snapshot**: higher limits (600/min) – not used here.\n- If you receive HTTP 429, honor `Retry-After` header and back‑off exponentially.\n- Avoid running during peak market hours (09:00–13:30 TW) if possible; schedule after 15:00 for daily updates.\n\n## Batch Processing with Checkpointing and Timeout Handling\nFor production use with resumable processing and timeout protection:\n\n```python\nimport json\nimport time\nfrom pathlib import Path\n\nclass CheckpointManager:\n    def __init__(self, checkpoint_path: Path):\n        self.checkpoint_path = checkpoint_path\n        self.processed = self._load()\n    \n    def _load(self):\n        if self.checkpoint_path.exists():\n            try:\n                with self.checkpoint_path.open() as f:\n                    return set(json.load(f).get('processed', []))\n            except Exception:\n                return set()\n        return set()\n    \n    def save(self):\n        try:\n            with self.checkpoint_path.open('w') as f:\n                json.dump({'processed': list(self.processed)}, f, ensure_ascii=False, indent=2)\n        except Exception as e:\n            print(f'Failed to save checkpoint: {e}')\n    \n    def mark_processed(self, item):\n        self.processed.add(item)\n        self.save()\n    \n    def is_processed(self, item):\n        return item in self.processed\n\ndef download_stocks_with_checkpoint(stock_codes, batch_size=50, max_runtime_seconds=300):\n    \"\"\"Download stocks in batches with checkpointing and runtime timeout.\"\"\"\n    checkpoint = CheckpointManager(Path('step2_checkpoint.json'))\n    limiter = TWSERateLimiter(max_per_minute=50)\n    conn = sqlite3.connect('taiwan_stocks.db')\n    \n    # Get unprocessed stocks\n    todo = [c for c in stock_codes if not checkpoint.is_processed(c)]\n    print(f'Total stocks: {len(stock_codes)}, Remaining: {len(todo)}')\n    \n    start_time = time.time()\n    total_inserted = 0\n    \n    for i in range(0, len(todo), batch_size):\n        # Check runtime timeout\n        if time.time() - start_time > max_runtime_seconds:\n            print(f'Reached maximum runtime ({max_runtime_seconds}s), saving checkpoint and stopping.')\n            break\n            \n        batch = todo[i:i+batch_size]\n        print(f'\\nProcessing batch {i//batch_size + 1}/{(len(todo)-1)//batch_size + 1}: {len(batch)} stocks')\n        \n        for code in batch:\n            try:\n                limiter.wait()\n                stock = twstock.Stock(code)\n                data = stock.fetch_from(2023, 1)  # Adjust start date as needed\n                \n                if not data:\n                    print(f'  {code}: No data')\n                    checkpoint.mark_processed(code)\n                    continue\n                \n                records = []\n                for d in data:\n                    records.append((\n                        d.date.strftime('%Y-%m-%d'),\n                        code,\n                        float(d.open) if d.open is not None else None,\n                        float(d.high) if d.high is not None else None,\n                        float(d.low) if d.low is not None else None,\n                        float(d.close) if d.close is not None else None,\n                        int(d.capacity) if d.capacity is not None else None,\n                        float(d.turnover) if d.turnover is not None else None,\n                        int(d.transaction) if d.transaction is not None else None,\n                        float(getattr(d, 'amplitude', None)) if getattr(d, 'amplitude', None) is not None else None\n                    ))\n                \n                if records:\n                    cur = conn.cursor()\n                    cur.executemany('''\n                        INSERT OR REPLACE INTO daily_prices\n                        (date, stock_code, open, high, low, close, volume, turnover, transaction_count, amplitude)\n                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\n                    ''', records)\n                    conn.commit()\n                    total_inserted += len(records)\n                    print(f'  {code}: Inserted/updated {len(records)} records')\n                else:\n                    print(f'  {code}: No valid records')\n                \n                # Mark as processed after each stock\n                checkpoint.mark_processed(code)\n                \n            except Exception as e:\n                print(f'  {code}: Error - {e}')\n                # Still mark as processed to avoid infinite retries on persistent errors\n                checkpoint.mark_processed(code)\n        \n        print(f'Completed batch {i//batch_size + 1}')\n    \n    conn.close()\n    print(f'\\nFinished. Total records inserted/updated: {total_inserted}')\n    return total_inserted\n```

## Verification
After any download, run:
```sql
SELECT COUNT(*) AS total_rows,
       COUNT(DISTINCT stock_code) AS stock_count
FROM daily_prices;
```
Expect `total_rows` ≈ (number of stocks) × (average trading days). 
Check for duplicates:
```sql
SELECT date, stock_code, COUNT(*) AS cnt
FROM daily_prices
GROUP BY date, stock_code
HAVING cnt > 1;
```
Should return zero rows.

## Maintenance
- **Backup**: Copy the `.db` file; SQLite is single‑file.
- **Vacuum**: Periodically run `VACUUM;` to reclaim space.
- **Data retention**: To keep only recent N years, delete older rows:
  ```sql
  DELETE FROM daily_prices WHERE date < date('now', '-5 year');
  VACUUM;
  ```
- **Schedule**: Use `cron` (Linux) or Task Scheduler (Windows) to run `download_today_only` each trading day after 15:30.

## References
- `twstock` documentation: https://twstock.readthedocs.io/
- TWSE OpenAPI: https://openapi.twse.com.tw/
- Rate limit reference (E‑Sun Securities API as proxy): https://www.esunsec.com.tw/trading-platforms/api-trading/docs/market-data/rate-limit/
- Session-specific learnings: references/session_learnings.md
- Checkpoint mechanism: references/checkpoint_pattern.md
- Retry reconciliation for cron-based batch downloads: references/retry_reconciliation.md
- Cron deployment guide (path resolution, timeout budgeting, error layers): references/cron_deployment.md
- Ready-to-use template: templates/batch_download_with_timeout.py

## Notes
- This skill was distilled from a live session where the user requested a step‑by‑step plan for downloading Taiwan stock data into SQLite while avoiding API bans.
- Key pitfalls discovered:
  1. The `twstock.Stock.fetch()` method requires `year` and `month` arguments; there is no no‑argument variant. Use `fetch_from(start_year, start_month)` to get data from that point to present.
  2. `transaction` is an SQL reserved keyword; rename column to `transaction_count` (or quote it) to avoid syntax errors.
  3. After calling `twse.update()` and `tpex.use()`, the combined stock codes are available in `twstock.codes` (not `twse.codes` or `tpex.codes` individually).
  4. The `amplitude` field may be `None` for some records; handle gracefully.
  5. **`twstock.Stock(code)` constructor can throw `TooManyRedirects` exceptions** — these are TWSE transient network failures, not invalid stock codes. Wrap BOTH `Stock(code)` and `stock.fetch_from()` in try/except. Never let `Stock()` throw uncaught; the stock is still valid on retry.
  6. **Batch downloads over Cron must fit within the cron timeout.** Estimate: each stock takes ~25s (rate-limit wait + TWSE fetch + DB write). For a 120s cron timeout, budget max 20 stocks/run. Add a time-check break in the loop with a 10s buffer before the cron deadline.
  7. **Retry candidates pattern:** When a stock fails with `TooManyRedirects` during `Stock()`, it's marked as "processed" in the checkpoint to avoid infinite retries. But the actual data may be valid. After the main run finishes, do a reconciliation pass: query `daily_prices` for stocks in the checkpoint with < 100 records — these are retry candidates. Re-add them to the todo list on the next run.
  8. **Performance reality:** 100 seconds of runtime × ~3.5s/stock ≈ only 4-5 stocks per batch on average, not 20. The bottleneck is the rate limiter (1.5s wait) plus the ~20-25s TWSE fetch time per stock. If speed matters, consider parallel fetching (e.g., concurrent.futures with ThreadPoolExecutor, keeping the rate limiter shared as a global lock).
- The approach prioritises safety (rate limiting) and simplicity (SQLite) over raw speed.
- For higher‑frequency data (intraday/tick), consider a dedicated time‑series database or message queue.

---