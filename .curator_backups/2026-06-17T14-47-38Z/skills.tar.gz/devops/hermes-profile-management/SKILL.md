---
name: hermes-profile-management
description: Manage multiple isolated Hermes Agent profiles for different workflows.
---

# Hermes Profile Management

Manage multiple isolated Hermes Agent profiles for different workflows (e.g., research, coding, testing). Each profile has its own config, `.env`, SOUL.md, skills, and cron jobs.

## When to Use
- You need separate environments with different API keys, models, or personas.
- You want to run multiple agents simultaneously without interference.
- You wish to experiment with a new configuration while keeping a stable default.

## Steps

### 1. List Existing Profiles
```bash
hermes profile list
```
Shows current profiles, their models, gateway status, and aliases.

### 2. Create a New Profile (Clone from Default or Another)
```bash
# Clone from the active profile (default if none set)
hermes profile create <profile-name> --clone

# To clone from a specific existing profile:
hermes profile create <profile-name> --clone-from <source-profile>
```
- `--clone` copies `config.yaml`, `.env`, `SOUL.md`, and skills from the source.
- A wrapper script is created at `~/.local/bin/<profile-name>` (add `~/.local/bin` to your `$PATH` for easy use).

### 3. Use a Profile
#### Direct Wrapper (if `$PATH` includes `~/.local/bin`)
```bash
<profile-name> chat          # start interactive chat
<profile-name> dashboard     # start the web dashboard
<profile-name> cron list     # view cron jobs for this profile
```
#### Explicit Profile Flag
```bash
hermes --profile <profile-name> chat
hermes --profile <profile-name> config show
```

### 4. Switch Default (Sticky) Profile
```bash
hermes profile use <profile-name>
```
After this, plain `hermes <command>` uses `<profile-name>` until changed.

### 5. Edit Profile Configuration
#### Edit config.yaml
```bash
hermes --profile <profile-name> config edit
```
#### Edit .env (API keys, model overrides)
```bash
hermes --profile <profile-name> config edit   # .env is edited via the same command
```
> **Note**: The `.env` file is secret‑bearing; the editor will open it but content is not displayed in tool outputs.

### 6. Customize SOUL.md (Persona / Instructions)
```bash
hermes --profile <profile-name> config edit   # then edit the SOUL.md file under the profile directory
```
Or directly:
```bash
$EDITOR /opt/data/profiles/<profile-name>/SOUL.md
```

### 7. Install / Sync Skills
Skills bundled with Hermes are synced automatically on `hermes update`.  
To add extra skills to a profile:
```bash
hermes --profile <profile-name> skills install <skill-name>
```
To view installed skills:
```bash
hermes --profile <profile-name> skills list
```

### 8. Delete a Profile (When No Longer Needed)
```bash
hermes profile delete <profile-name>
```
This removes the profile directory and its wrapper script.  
**Warning**: This action cannot be undone.

## Pitfalls & Troubleshooting
- **Wrapper not found**: Ensure `~/.local/bin` is in your `$PATH`. Add `export PATH="$HOME/.local/bin:$PATH"` to your shell rc file.
- **Dashboard binds only to localhost**: By default the dashboard refuses to bind to `0.0.0.0` unless an auth provider is configured or `--insecure` is set. For external access (e.g., via Tailscale) set:
  ```bash
  export HERMES_DASHBOARD_INSECURE=1   # only on trusted networks
  export HERMES_DASHBOARD_PORT=8501
  export HERMES_DASHBOARD_HOST=0.0.0.0
  ```
  Then restart the dashboard service (`hermes dashboard --stop` then `hermes dashboard`).
- **Environment variables not persisting**: Variables set in the shell do not affect the supervised dashboard service. To make them permanent, edit the profile’s `.env` or configure via `hermes config set` inside the profile.
- **Cloning from wrong source**: Verify the source profile with `hermes profile list` before using `--clone-from`.
- **Forgot to reload after SOUL.md changes**: Restart the chat session or run `hermes profile use <name>` again to pick up updates.

## Verification
After creating a profile, confirm isolation:
```bash
# Check that .env differs
diff /opt/data/.hermes/.env /opt/data/profiles/<profile-name>/.env

# Ensure skills directory is separate
ls /opt/data/profiles/<profile-name>/skills/
```

## References
- See `hermes profile --help` for all subcommands.
- For dashboard external access troubleshooting, refer to the skill `hermes-dashboard-troubleshooting` (if available) or the Hermes docs on `HERMES_DASHBOARD_INSECURE`.
