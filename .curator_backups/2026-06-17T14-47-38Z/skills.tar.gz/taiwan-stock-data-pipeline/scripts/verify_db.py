import sqlite3
from pathlib import Path

def main(db_path='/opt/data/taiwan_stocks.db'):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM daily_prices")
    row_count = c.fetchone()[0]
    c.execute("SELECT COUNT(DISTINCT stock_code) FROM daily_prices")
    stock_count = c.fetchone()[0]
    c.execute("SELECT MIN(date), MAX(date) FROM daily_prices")
    date_range = c.fetchone()
    print(f'Rows: {row_count}')
    print(f'Distinct stocks: {stock_count}')
    print(f'Date range: {date_range}')
    # Optional: show a few sample rows
    c.execute("SELECT stock_code, date, close FROM daily_prices ORDER BY date DESC LIMIT 5")
    rows = c.fetchall()
    print('Most recent 5 rows (any stock):')
    for r in rows:
        print(r)
    conn.close()

if __name__ == "__main__":
    main()