import twstock
import sqlite3
import time
import json
from pathlib import Path

# Rate limiter: max requests per minute
MAX_PER_MINUTE = 50  # conservative to stay under 60
MIN_INTERVAL = 60.0 / MAX_PER_MINUTE

class RateLimiter:
    def __init__(self):
        self.last_request = 0.0
    
    def wait(self):
        elapsed = time.time() - self.last_request
        if elapsed < MIN_INTERVAL:
            time.sleep(MIN_INTERVAL - elapsed)
        self.last_request = time.time()

def init_db(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS daily_prices (
            date TEXT NOT NULL,
            stock_code TEXT NOT NULL,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume INTEGER,
            turnover REAL,
            transaction_count INTEGER,
            amplitude REAL,
            PRIMARY KEY (date, stock_code)
        );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);")
    conn.commit()
    return conn

def fetch_stock_data(stock_code, limiter, start_year=2023, start_month=1):
    """Fetch historical data for a single stock from start_year/start_month with timeout protection."""
    import threading
    
    result = []
    exception = []
    
    def fetch_target():
        try:
            limiter.wait()
            stock = twstock.Stock(stock_code)
            data = stock.fetch_from(start_year, start_month)
            if not data:
                result.append([])
                return
            records = []
            for d in data:
                records.append((
                    d.date.strftime('%Y-%m-%d'),
                    stock_code,
                    float(d.open) if d.open is not None else None,
                    float(d.high) if d.high is not None else None,
                    float(d.low) if d.low is not None else None,
                    float(d.close) if d.close is not None else None,
                    int(d.capacity) if d.capacity is not None else None,
                    float(d.turnover) if d.turnover is not None else None,
                    int(d.transaction) if d.transaction is not None else None,
                    float(getattr(d, 'amplitude', None)) if getattr(d, 'amplitude', None) is not None else None
                ))
            result.append(records)
        except Exception as e:
            exception.append(e)
    
    # Run fetch in a thread with timeout
    thread = threading.Thread(target=fetch_target)
    thread.daemon = True
    thread.start()
    thread.join(timeout=30)  # 30 second timeout per stock
    
    if thread.is_alive():
        # Timeout occurred
        print(f"Timeout fetching {stock_code} after 30 seconds")
        return []
    
    if exception:
        print(f"Error fetching {stock_code}: {exception[0]}")
        return []
        
    return result[0] if result else []

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Download Taiwan stock daily data to SQLite')
    parser.add_argument('--db', default='/opt/data/taiwan_stocks.db', help='Path to SQLite database')
    parser.add_argument('--start-year', type=int, default=2023, help='Start year for data fetch')
    parser.add_argument('--start-month', type=int, default=1, help='Start month for data fetch')
    parser.add_argument('--checkpoint', default='/opt/data/step2_checkpoint.json', help='Checkpoint file path')
    parser.add_argument('--max-stocks', type=int, default=0, help='Maximum number of stocks to process in this run (0 = process all)')
    args = parser.parse_args()
    
    db_path = Path(args.db)
    checkpoint_path = Path(args.checkpoint)
    
    conn = init_db(db_path)
    cursor = conn.cursor()
    
    # Update stock lists once
    print("Updating TWSE and TPEX stock lists...")
    twstock.twse.update()
    twstock.tpex.update()
    
    # Get all stock codes of type '股票'
    all_codes = {}
    for code, info in twstock.codes.items():
        if info.type == '股票':
            all_codes[code] = info
    print(f"Total stocks (type='股票'): {len(all_codes)}")
    
    # Determine which stocks are already in DB
    cursor.execute("SELECT DISTINCT stock_code FROM daily_prices")
    existing_codes = {row[0] for row in cursor.fetchall()}
    print(f"Already in DB: {len(existing_codes)} stocks")
    
    # Stocks to process
    to_process = {code: info for code, info in all_codes.items() if code not in existing_codes}
    print(f"To process: {len(to_process)} stocks")
    
    # Load checkpoint for resume within this run (in case of interruption)
    processed_set = set()
    if checkpoint_path.exists():
        try:
            with open(checkpoint_path, 'r') as f:
                data = json.load(f)
                processed_set = set(data.get('processed', []))
                print(f"Loaded checkpoint: {len(processed_set)} stocks already processed")
        except Exception as e:
            print(f"Failed to load checkpoint: {e}")
    
    # Remove any already processed from to_process
    to_process = {code: info for code, info in to_process.items() if code not in processed_set}
    print(f"After checkpoint, remaining: {len(to_process)} stocks")
    
    limiter = RateLimiter()
    total_inserted = 0
    processed_count = 0
    batch_size = 1  # Process and commit one stock at a time to prevent timeouts (based on session experience)

    for code, info in to_process.items():
        processed_count += 1
        print(f"[{processed_count}/{len(to_process)}] Processing {code} ({info.name})...", end=' ')
        records = fetch_stock_data(code, limiter, args.start_year, args.start_month)
        if records:
            cursor.executemany("""
                INSERT OR REPLACE INTO daily_prices 
                (date, stock_code, open, high, low, close, volume, turnover, transaction_count, amplitude)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, records)
            inserted = len(records)
            total_inserted += inserted
            print(f"Inserted/Updated {inserted} records.")
        else:
            print("No data or error.")
        
        # Update checkpoint after each stock to prevent losing progress on timeout
        processed_set.add(code)
        try:
            with open(checkpoint_path, 'w') as f:
                json.dump({'processed': list(processed_set)}, f)
        except Exception as e:
            print(f"Failed to save checkpoint: {e}")
        
        # Commit after each stock for safety
        conn.commit()
        print(f"Committed after {processed_count} stocks.")
    
    # Final commit and checkpoint
    conn.commit()
    try:
        with open(checkpoint_path, 'w') as f:
            json.dump({'processed': list(processed_set)}, f)
    except Exception as e:
        print(f"Failed to save checkpoint: {e}")
    print(f"\nFinished. Processed: {processed_count}, Total records inserted/updated: {total_inserted}")
    conn.close()

if __name__ == "__main__":
    main()