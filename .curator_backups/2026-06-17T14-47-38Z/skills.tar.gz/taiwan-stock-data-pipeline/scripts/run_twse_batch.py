#!/opt/hermes/.venv/bin/python
"""TWSE/TPEX stock daily data downloader - batch runner for Cron.

Features:
  - Batch size auto-calculated to fit within a time budget (default 100s)
  - Rate limiter: max 40 requests/min (~1.5s between requests)
  - Checkpoint resume via step2_checkpoint.json
  - Writes to taiwan_stocks.db via INSERT OR REPLACE
  - Prints progress summary at end
"""
import twstock, sqlite3, json, os, time, sys
from pathlib import Path

# ----- Configuration -----
TIME_BUDGET_SEC = 100        # max wall-clock seconds for this run (fit inside cron timeout)
MIN_INTERVAL = 1.5           # seconds between API requests (40/min ≈ 1.5s)
DB_PATH = '/opt/data/taiwan_stocks.db'
CP_PATH = '/opt/data/step2_checkpoint.json'

# ----- Rate Limiter -----
class RateLimiter:
    def __init__(self, min_interval=1.5):
        self.min_interval = min_interval
        self._last = 0.0
    def wait(self):
        now = time.time()
        elapsed = now - self._last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self._last = time.time()

limiter = RateLimiter(min_interval=MIN_INTERVAL)

# ----- Init DB -----
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
cur.execute('''
    CREATE TABLE IF NOT EXISTS daily_prices (
        date TEXT NOT NULL,
        stock_code TEXT NOT NULL,
        open REAL,
        high REAL,
        low REAL,
        close REAL,
        volume INTEGER,
        turnover REAL,
        transaction_count INTEGER,
        amplitude REAL,
        PRIMARY KEY (date, stock_code)
    );
''')
cur.execute('CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);')
cur.execute('CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);')
conn.commit()

# ----- Load checkpoint -----
cp_path = Path(CP_PATH)
processed_set = set()
if cp_path.exists():
    try:
        with cp_path.open() as f:
            data = json.load(f)
            processed_set = set(data.get('processed', []))
    except Exception:
        processed_set = set()

# ----- Get all stock codes -----
twstock.twse.update()
twstock.tpex.update()
all_codes = {c: i for c, i in twstock.codes.items() if i.type == '股票'}
todo = [c for c in all_codes if c not in processed_set]

# ----- Calculate batch size from time budget -----
# Each stock takes ~20-25s TWSE fetch + 1.5s rate-limit wait ≈ 5s total
BATCH_SIZE = max(1, int(TIME_BUDGET_SEC / 5))
batch = todo[:BATCH_SIZE]

print(f'本次將處理 {len(batch)} 支股票（剩餘 {len(todo)} 支）')
sys.stdout.flush()

total_inserted = 0
newly_processed = []
start_time = time.time()

for code in batch:
    # Check time budget: stop early if running out of time
    elapsed = time.time() - start_time
    if elapsed >= TIME_BUDGET_SEC - 10:  # leave 10s buffer for checkpoint write
        print(f'  ⏰ 時間預算將盡 ({elapsed:.0f}s)，提前結束本批次')
        sys.stdout.flush()
        break
    limiter.wait()
    stock = twstock.Stock(code)
    try:
        data = stock.fetch_from(2023, 1)
    except Exception as e:
        print(f'  {code}: 獲取資料失敗 {e}')
        sys.stdout.flush()
        newly_processed.append(code)
        continue
    if not data:
        print(f'  {code}: 無資料')
        sys.stdout.flush()
        newly_processed.append(code)
        continue
    records = []
    for d in data:
        records.append((
            d.date.strftime('%Y-%m-%d'),
            code,
            float(d.open) if d.open is not None else None,
            float(d.high) if d.high is not None else None,
            float(d.low) if d.low is not None else None,
            float(d.close) if d.close is not None else None,
            int(d.capacity) if d.capacity is not None else None,
            float(d.turnover) if d.turnover is not None else None,
            int(d.transaction) if d.transaction is not None else None,
            float(getattr(d, 'amplitude', None)) if getattr(d, 'amplitude', None) is not None else None
        ))
    if records:
        cur.executemany('''
            INSERT OR REPLACE INTO daily_prices
            (date, stock_code, open, high, low, close, volume, turnover, transaction_count, amplitude)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', records)
        conn.commit()
        total_inserted += len(records)
        newly_processed.append(code)
        print(f'  {code}: 寫入/更新 {len(records)} 筆')
        sys.stdout.flush()
    else:
        newly_processed.append(code)

# Update checkpoint
processed_set.update(newly_processed)
try:
    with cp_path.open('w') as f:
        json.dump({'processed': list(processed_set)}, f, ensure_ascii=False, indent=2)
except Exception as e:
    print(f'寫入 checkpoint 失敗: {e}')
    sys.stdout.flush()

# ----- Report completion percentage -----
total_stocks = len(all_codes)
processed_count = len(processed_set)
percent = processed_count / total_stocks * 100
print(f'=== 進度回報：已處理 {processed_count}/{total_stocks} 支股票 ({percent:.1f}%) ===')
sys.stdout.flush()