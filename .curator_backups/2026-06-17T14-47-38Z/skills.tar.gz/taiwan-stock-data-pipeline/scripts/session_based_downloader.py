#!/usr/bin/env python3
"""
Session-based downloader for Taiwan stock data - optimized for cron job execution.
Based on lessons learned from actual pipeline runs:
- Process limited stocks per run to avoid timeouts (2-5 stocks recommended)
- Save checkpoint after each stock to prevent losing progress
- Commit after each stock for data safety
- Include per-stock timeout protection
"""

import twstock
import sqlite3
import json
import time
from pathlib import Path
from threading import Thread


class RateLimiter:
    def __init__(self, per_minute=40):
        self.min_interval = 60.0 / per_minute
        self._last = 0.0
    
    def wait(self):
        now = time.time()
        elapsed = now - self._last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self._last = now


def init_db(db_path):
    """Initialize database with required schema."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS daily_prices (
            date TEXT NOT NULL,
            stock_code TEXT NOT NULL,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume INTEGER,
            turnover REAL,
            transaction_count INTEGER,
            amplitude REAL,
            PRIMARY KEY (date, stock_code)
        );
    ''')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);')
    conn.commit()
    return conn


def fetch_stock_data_with_timeout(stock_code, limiter, start_year=2023, start_month=1, timeout=30):
    """
    Fetch historical data for a single stock with timeout protection.
    Returns list of records or empty list on failure/timeout.
    """
    result = []
    exception = []
    
    def fetch_target():
        try:
            limiter.wait()
            stock = twstock.Stock(stock_code)
            data = stock.fetch_from(start_year, start_month)
            if not data:
                result.append([])
                return
            
            records = []
            for d in data:
                records.append((
                    d.date.strftime('%Y-%m-%d'),
                    stock_code,
                    float(d.open) if d.open is not None else None,
                    float(d.high) if d.high is not None else None,
                    float(d.low) if d.low is not None else None,
                    float(d.close) if d.close is not None else None,
                    int(d.capacity) if d.capacity is not None else None,
                    float(d.turnover) if d.turnover is not None else None,
                    int(d.transaction) if d.transaction is not None else None,
                    float(getattr(d, 'amplitude', None)) if getattr(d, 'amplitude', None) is not None else None
                ))
            result.append(records)
        except Exception as e:
            exception.append(e)
    
    thread = Thread(target=fetch_target)
    thread.daemon = True
    thread.start()
    thread.join(timeout=timeout)
    
    if thread.is_alive():
        print(f"  Timeout fetching {stock_code} after {timeout} seconds")
        return []
    
    if exception:
        print(f"  Error fetching {stock_code}: {exception[0]}")
        return []
    
    return result[0] if result else []


def main():
    """Main execution function for session-based processing."""
    import argparse
    parser = argparse.ArgumentParser(description='Download Taiwan stock data - session optimized')
    parser.add_argument('--db', default='/opt/data/taiwan_stocks.db', help='SQLite database path')
    parser.add_argument('--checkpoint', default='/opt/data/step2_checkpoint.json', help='Checkpoint file')
    parser.add_argument('--start-year', type=int, default=2023, help='Start year for data fetch')
    parser.add_argument('--start-month', type=int, default=1, help='Start month for data fetch')
    parser.add_argument('--max-stocks', type=int, default=3, help='Max stocks to process this run (0=all)')
    parser.add_argument('--timeout', type=int, default=30, help='Per-stock timeout in seconds')
    args = parser.parse_args()
    
    # Initialize
    db_path = Path(args.db)
    checkpoint_path = Path(args.checkpoint)
    conn = init_db(db_path)
    cur = conn.cursor()
    
    # Update stock lists
    print("Updating TWSE and TPEX stock lists...")
    twstock.twse.update()
    twstock.tpex.update()
    
    # Get all stocks
    all_codes = {c: i for c, i in twstock.codes.items() if i.type == '股票'}
    print(f"Total stocks: {len(all_codes)}")
    
    # Determine remaining stocks
    cur.execute("SELECT DISTINCT stock_code FROM daily_prices")
    existing = {row[0] for row in cur.fetchall()}
    to_process = {c: i for c, i in all_codes.items() if c not in existing}
    print(f"Remaining to process: {len(to_process)}")
    
    # Load checkpoint
    processed_set = set()
    if checkpoint_path.exists():
        try:
            with checkpoint_path.open() as f:
                data = json.load(f)
                processed_set = set(data.get('processed', []))
                print(f"Loaded checkpoint: {len(processed_set)} stocks processed")
        except Exception as e:
            print(f"Failed to load checkpoint: {e}")
    
    # Remove already processed
    to_process = {c: i for c, i in to_process.items() if c not in processed_set}
    print(f"After checkpoint: {len(to_process)} stocks to process")
    
    # Limit batch size
    if args.max_stocks > 0:
        items = list(to_process.items())[:args.max_stocks]
        to_process = dict(items)
        print(f"Limited to {len(to_process)} stocks for this run")
    
    # Process stocks
    limiter = RateLimiter(per_minute=40)
    total_inserted = 0
    newly_processed = []
    
    for code, info in to_process.items():
        print(f"Processing {code} ({info.name})...", end=' ')
        start_time = time.time()
        
        records = fetch_stock_data_with_timeout(
            code, limiter, args.start_year, args.start_month, args.timeout
        )
        
        if records:
            cur.executemany('''
                INSERT OR REPLACE INTO daily_prices
                (date, stock_code, open, high, low, close, volume, turnover, transaction_count, amplitude)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', records)
            conn.commit()
            total_inserted += len(records)
            newly_processed.append(code)
            print(f"Inserted {len(records)} records")
        else:
            newly_processed.append(code)  # Still mark as processed to avoid retry loop
            print("No data or error")
        
        elapsed = time.time() - start_time
        print(f"  (took {elapsed:.1f}s)")
        
        # Save checkpoint after each stock
        processed_set.add(code)
        try:
            with checkpoint_path.open('w') as f:
                json.dump({'processed': list(processed_set)}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"  Failed to save checkpoint: {e}")
    
    # Final summary
    processed_set.update(newly_processed)
    try:
        with checkpoint_path.open('w') as f:
            json.dump({'processed': list(processed_set)}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Failed to save final checkpoint: {e}")
    
    print(f"\n=== RUN COMPLETE ===")
    print(f"Stocks processed: {len(newly_processed)}")
    print(f"Records inserted/updated: {total_inserted}")
    print(f"Total processed so far: {len(processed_set)}")
    print(f"Remaining: {len(all_codes) - len(processed_set)}")
    
    conn.close()


if __name__ == "__main__":
    main()