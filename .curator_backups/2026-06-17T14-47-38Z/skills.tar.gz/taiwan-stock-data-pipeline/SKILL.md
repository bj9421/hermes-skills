---
name: taiwan-stock-data-pipeline
description: A reproducible pipeline for downloading historical daily price data for all Taiwan stocks (TWSE + TPEX) and storing it in a SQLite database. Includes rate‑limiting to avoid API bans, checkpoint‑based resumability, and upsert logic to keep the database current.
category: data-science
---
# Taiwan Stock Daily Data Pipeline

## Description
A reproducible pipeline for downloading historical daily price data for all Taiwan stocks (TWSE + TPEX) and storing it in a SQLite database. Includes rate‑limiting to avoid API bans, checkpoint‑based resumability, upsert logic to keep the database current, and comprehensive troubleshooting guidance for common issues like database locking and corruption.

## Trigger Conditions
- User wants to obtain Taiwan stock OHLCV (open, high, low, close, volume, turnover) data for backtesting, analysis, or model training.
- User prefers a lightweight, zero‑maintenance storage format (SQLite) that can be queried with SQL or pandas.
- User needs the pipeline to be resumable and respectful of TWSE/TPEX API rate limits.

## Prerequisites
- Python 3.8+
- `twstock` package (install via `pip install twstock` - pandas is optional but useful for analysis)
- Sufficient disk space for the SQLite database (historical daily data for ~1900 stocks over several years is ~200‑300 MB).
- For production use, consider setting up a cron job or similar scheduler for automated processing.

## Workflow

### 1. Prepare Environment
```bash
pip install twstock
# pandas is optional but useful for analysis: pip install pandas
```

### 2. Initialise Database Schema
Run once to create the `daily_prices` table with a composite primary key `(date, stock_code)`:
```sql
CREATE TABLE IF NOT EXISTS daily_prices (
    date TEXT NOT NULL,
    stock_code TEXT NOT NULL,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,
    turnover REAL,
    transaction_count INTEGER,
    amplitude REAL,
    PRIMARY KEY (date, stock_code)
);
CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);
CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);
```

### 3. Download Historical Data with Rate Limiting & Checkpointing\\nUse the provided Python script (`download_taiwan_stocks.py`) which:\\\\n- Updates the TWSE/TPEX code lists once using `twstock.twse.update()` and `twstock.tpex.update()`.\\\\n- Gets all stock codes where `stock.type == '股票'` from `twstock.codes` (note: `twstock.codes` is a dictionary mapping codes to StockCodeInfo objects).\\\\n- For each stock, calls `twstock.Stock.fetch_from(start_year, start_month)` (default 2023‑01).\\\\n- Applies a `RateLimiter` class that enforces a minimum interval between requests (configured to 40 requests/minute, or ≥1.5 s between requests) to stay safely under the TWSE historical limit of 60 requests/minute.\\\\n- Processes stocks with optional limiting via `--max-stocks` parameter (default 0 = process all remaining stocks).\\\\n- Converts each record to a tuple and upserts via `INSERT OR REPLACE` to handle both inserts and updates.\\\\n- **Commits immediately after each stock** (changed from batch commits) to prevent losing progress on timeouts and ensure checkpoint can be saved for each processed stock.\\\\n- Saves a JSON checkpoint after each stock to `/opt/data/step2_checkpoint.json` so the run can be resumed after interruption.\\\\n- Includes per-stock timeout handling (30 seconds) to prevent hanging on problematic stocks.\\\\n- Based on operational experience, processing **one stock at a time** (with immediate commit) has proven most reliable to prevent timeouts and data loss. Each stock typically takes 20-25 seconds to fetch historical data from 2023-present.\\\\n- Can be run manually for testing or scheduled via cron for automated processing.\\\\n- **Key learned practice**: Always commit after each stock and save checkpoint immediately after to ensure no progress is lost on interruption or timeout.

### 4. Schedule Automated Processing with Cron

Two approaches for cron scheduling:

#### Approach A: `no_agent` + shell script wrapper (recommended for reliability)
The cron `no_agent` mode runs the script directly and delivers its stdout verbatim — no LLM tokens consumed.

Create a shell wrapper at `scripts/run_twse_batch.sh` (Cron resolves scripts relative to `workdir/scripts/`):
```bash
#!/usr/bin/env bash
cd /opt/data
/opt/hermes/.venv/bin/python /opt/data/run_twse_batch.py
```
Then schedule:
```bash
hermes cronjob action=create \
  --name "twse_batch_50per10m" \
  --schedule "*/10 * * * *" \
  --script "run_twse_batch.sh" \
  --no-agent true \
  --workdir /opt/data \
  --deliver origin
```

**Important path resolution quirk**: When `no_agent=true` and `workdir=/opt/data`, the `script` value `run_twse_batch.sh` resolves to `/opt/data/scripts/run_twse_batch.sh`. Do NOT prefix with `./`, `.hermes/scripts/`, or any relative path — those cause double-pathing errors like `/opt/data/scripts/.hermes/scripts/run_twse_batch.sh`.

#### Approach B: LLM-driven prompt
```bash
hermes cronjob action=create \
  --name "twse_batch_cron" \
  --schedule "*/10 * * * *" \
  --prompt "cd /opt/data && /opt/hermes/.venv/bin/python download_taiwan_stocks.py" \
  --deliver origin
```

This job will:
- Automatically resume from where it left off using the checkpoint file
- Process a limited number of new stocks per execution (batch calculated from cron timeout budget)
- Run indefinitely until all stocks are processed
- Send progress reports back to the originating chat

**Batch Sizing Strategy (CRITICAL)**: Based on operational experience, each stock fetch from 2023 takes ~20-25s network time + rate-limiter wait ≈ 22-27s per stock. The cron timeout is 180s (configured for `no_agent`). Calculate batch size from a **time budget**, not a fixed number:\n\n```python\nTIME_BUDGET_SEC = 150       # leave 30s buffer for checkpoint writes\nESTIMATED_SEC_PER_STOCK = 20 # realistic estimate based on observed performance\nBATCH_SIZE = max(1, int(TIME_BUDGET_SEC / ESTIMATED_SEC_PER_STOCK))\n# → 7 stocks per batch\n```\n\nAdd an early-stop guard in the loop:\n```python\nstart_time = time.time()\nfor code in batch:\n    elapsed = time.time() - start_time\n    if elapsed >= TIME_BUDGET_SEC - 10:  # 10s buffer for final checkpoint\n        break\n    limiter.wait()\n    # ... fetch and process stock\n```\n\nSee `scripts/run_twse_batch.py` for a production-tested implementation using this pattern. This approach processes ~7 stocks per 10-minute cron tick (vs 1-3 with the old advice).

### 5. Verify Ingestion
After the run completes, check the database:
```sql
SELECT COUNT(*) AS rows, COUNT(DISTINCT stock_code) AS stocks FROM daily_prices;
SELECT MIN(date), MAX(date) FROM daily_prices;
```

### 6. Optional: Daily Incremental Update
For a production‑ready daily refresh, replace the historical fetch with a call that retrieves only the most recent trading day (e.g., fetch from the current month and filter to today’s date) and schedule the script to run after market close (around 15:30 TW time) using cron or Windows Task Scheduler.
```sql
SELECT COUNT(*) AS rows, COUNT(DISTINCT stock_code) AS stocks FROM daily_prices;
SELECT MIN(date), MAX(date) FROM daily_prices;
```

## Progress Reporting & Monitoring

Based on operational experience and user preferences, monitoring progress effectively requires combining database queries with checkpoint file analysis, and providing regular updates via cron job output.

### Progress Calculation
To calculate completion percentage at any point:
```python
import json, sqlite3
from pathlib import Path

# Get total stocks (update as needed or fetch dynamically)
total_stocks = 1925  # Approximate total TWSE+TPEX stocks

# Get processed count from checkpoint
checkpoint_path = Path('/opt/data/step2_checkpoint.json')
if checkpoint_path.exists():
    with open(checkpoint_path) as f:
        data = json.load(f)
        processed_count = len(data.get('processed', []))
else:
    # Fallback: count from database
    conn = sqlite3.connect('/opt/data/taiwan_stocks.db')
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(DISTINCT stock_code) FROM daily_prices')
    processed_count = cursor.fetchone()[0]
    conn.close()

# Calculate percentage
percentage = (processed_count / total_stocks) * 100
print(f'Progress: {processed_count}/{total_stocks} stocks ({percentage:.1f}%)')
```

### Real-time Monitoring Recommendations
1. **During active processing**: Check the checkpoint file for the most accurate count of processed stocks
2. **When database is not locked**: Query the database for precise stock and record counts
3. **Avoid frequent database queries during writes**: To prevent locking issues, prefer checkpoint-based monitoring during active downloads
4. **Cron job output**: The scheduled job outputs progress information including:
   - Number of stocks being processed in the current run
   - Remaining stock count
   - Records inserted/updated per stock
   - Final progress percentage after each run (in both English and Chinese as per user preference)

Example progress output (as delivered by cron job):
```
本次將處理 50 支股票（剩餘 1649 支）
  4304: 寫入/更新 824 筆
  4305: 寫入/更新 824 筆
  === 進度回報：已處理 281/1925 支股票 (14.6%) ===
```

### Implementation Notes
- The progress percentage is calculated based on the checkpoint file which tracks successfully processed stocks
- Each cron job run processes a limited batch (default 50 stocks) to avoid timeouts
- After each stock is processed, the script commits to the database and updates the checkpoint immediately
- This ensures no progress is lost if the process is interrupted
- The cron job delivers output back to the originating chat, providing regular progress updates

## Pitfalls & Mitigations
- **API 429 Errors**: If you see HTTP 429, increase the wait time between requests (raise `MIN_INTERVAL`) or reduce `MAX_PER_MINUTE`. The built‑in `RateLimiter` already uses a conservative 50 rpm.
- **Missing Data for Certain Dates**: Some stocks may be suspended or delisted; the script skips stocks that return no data.
- **Primary Key Violations**: The upsert pattern (`INSERT OR REPLACE`) guarantees that re‑running the same day will update rather than duplicate rows.
- **Checkpoint Drift**: If you change the `start_year`/`start_month` after a checkpoint has been saved, delete the checkpoint file (`step2_checkpoint.json`) to avoid skipping stocks unintentionally.
- **Large Historical Spans**: Fetching from a very early date (e.g., 2000) increases per‑stock download time considerably. Consider starting from a more recent year and filling older gaps in separate runs if needed.
- **Database Locking During Reads**: Attempting to query the database while the download script is running may result in "database is locked" errors. This is expected when using SQLite with concurrent read/write operations. For monitoring progress during a run:
  * Use the checkpoint file (e.g., step2_checkpoint.json) for processed counts
  * Try read-only URI connection with retry logic: sqlite3.connect('file:path.db?mode=ro', uri=True, timeout=10.0) and implement retry mechanisms for locked databases
  * Note that file copies may be malformed if taken mid-transaction (check for "database disk image is malformed" errors)
  * Fall back to checkpoint-only reporting if database is locked
  * To avoid locking issues entirely, consider scheduling verification during off-hours or using a separate read-replica database for reporting
- **Fetch Timeouts**: Individual stock data fetches can hang indefinitely due to network issues or API problems. The updated script implements per-stock timeouts (30 seconds) using threading to prevent the entire pipeline from stalling on a single problematic stock. Since the script processes stocks one at a time with immediate commits, overall script timeouts are primarily caused by individual stock fetch timeouts or network issues. If you encounter timeouts in cron jobs, first check your network connection, then consider:
  1. Increasing the per-stock timeout value in the script if stocks consistently require more time to download
  2. Reducing the batch size (stocks processed per cron run) by adjusting the time budget calculation
  3. Implementing more aggressive early-stop guards in the processing loop
- **Expected Duration**: A full historical download from 2023-01 for all ~1900 stocks takes approximately 10-15 hours depending on network conditions. For initial testing or pipeline validation, consider using a more recent start date (e.g., 2024-01) which reduces the time to 3-5 hours.

# Session Learnings: Taiwan Stock Data Pipeline (2026-06-06, 2026-06-07)

## Key Learnings from Debugging Cron Job Failures

### 1. Cron Script Path Resolution Quirk
When using Hermes cron with `no_agent=true` and a specified `workdir`:
- The `script` parameter resolves relative to `{workdir}/scripts/`
- Do NOT use relative paths like `./` or `.hermes/scripts/` prefixes
- Correct: `script: "run_twse_batch.sh"` with `workdir: "/opt/data"` → resolves to `/opt/data/scripts/run_twse_batch.sh`
- Incorrect: `script: ".hermes/scripts/run_twse_batch.sh"` → resolves to `/opt/data/scripts/.hermes/scripts/run_twse_batch.sh` (doesn't exist)

### 2. Timeout Management Strategy
Stock data fetching from TWSE takes ~20-25 seconds per stock (2023-present data) plus rate limiting.
- Default Hermes cron timeout is 120 seconds for `no_agent` jobs
- Leave 10-20 seconds buffer for checkpoint writes and overhead
- Calculate batch size from time budget: `BATCH_SIZE = max(1, int(TIME_BUDGET_SEC / ESTIMATED_SEC_PER_STOCK))`
- For 100-second time budget and 30-second estimate per stock: ~3 stocks per batch
- For 150-second time budget and 20-second estimate per stock: ~7 stocks per batch
- Add early-stop guard in processing loop to respect time budget

### 3. Robust Error Handling
Both `Stock()` constructor and `fetch_from()` can fail:
- Wrap `Stock()` construction in try/except for initialization failures (e.g., TooManyRedirects)
- Wrap `fetch_from()` in try/except for network/API errors
- Continue processing other stocks when individual stocks fail
- Mark failed stocks as "processed" in checkpoint to avoid infinite retry loops

### 4. Intelligent Retry Mechanism
Track retry counts to prevent endless retries on permanently problematic stocks:
- Only retry stocks with < 100 records in database (likely incomplete downloads)
- Limit retries to 3 attempts per stock
- After 3 failed attempts, treat as permanently problematic and move on
- Store retry counts in a separate JSON file (`step2_retry_counter.json`)

### 5. Progress Reporting Preferences
User prefers bilingual progress updates (English + Chinese) showing:
- Number of stocks being processed in current batch
- Remaining stock count
- Records inserted/updated per stock
- Final progress percentage after each run
- Format: `本次將處理 X 支股票（剩餘 Y 支）` followed by per-stock results and `=== 進度回報：已處理 A/B 支股票 (C%) ===`

### 6. Verification After Completion
After pipeline finishes, verify data integrity with:
- Total row count and distinct stock count
- Date range validation
- Spot-check for NULL values and price logic errors
- Check for stocks with unusually low record counts (newly listed stocks)

## Implementation Status Updates

### Implementation Status Updates

### 2026-06-06 Implementation:
- All learnings from this session have been successfully implemented and tested:
  - Cron timeout increased to 180 seconds via `hermes config set cron.script_timeout_seconds 180`
  - Python script updated with time budget approach (100 seconds) and dynamic batch sizing (~3 stocks/batch)
  - Added intelligent retry mechanism with `step2_retry_counter.json` to limit retries on problematic stocks
  - Enhanced error handling to catch both `Stock()` constructor and `fetch_from()` failures
  - Progress reporting maintains bilingual format as per user preference
  - Verified no more timeout errors in cron job execution
  - Pipeline now processes stocks reliably with automatic resumability and checkpointing

### 2026-06-07 Optimization:
- Increased timeout utilization: adjusted script time budget from 100s to 150s (leveraging the 180s cron limit)
- Improved throughput: reduced MIN_INTERVAL from 1.5s to 1.09s (~55 requests/minute from ~40 requests/minute)
- Enhanced batch size: increased from ~3 stocks/batch to ~7 stocks/batch
- Maintained reliability: kept intelligent retry mechanism and robust error handling
- Verified performance: processing rate increased from ~3 to ~7 stocks per 10-minute cron cycle
- Current status: pipeline processes stocks efficiently with automatic resumability and checkpointing

### 2026-06-07 Completion & Daily Update Setup:
- Historical backfill completed: All 1925 Taiwan stocks (TWSE + TPEX) now have complete historical daily data from 2016-03-01 to 2026-06-05
- Historical jobs paused: twse_batch_50per10m and twse_completion_check cron jobs paused after completion
- Daily update job established: New twse_daily_update cron job created to fetch previous trading day data daily at 16:06

### 2026-06-07 Optimization:
- Increased timeout utilization: adjusted script time budget from 100s to 150s (leveraging the 180s cron limit)
- Improved throughput: reduced MIN_INTERVAL from 1.5s to 1.09s (~55 requests/minute from ~40 requests/minute)
- Enhanced batch size: increased from ~3 stocks/batch to ~7 stocks/batch
- Maintained reliability: kept intelligent retry mechanism and robust error handling
- Verified performance: processing rate increased from ~3 to ~7 stocks per 10-minute cron cycle
- Current status: pipeline processes stocks efficiently with automatic resumability and checkpointing
   ```
4. **Ensure proper permissions** on both scripts:
   ```bash
   chmod +x /opt/data/run_twse_batch.py
   chmod +x /opt/data/.hermes/scripts/run_twse_batch.sh
   ```

### Database Locking and Corruption
If you encounter `sqlite3.DatabaseError: database disk image is malformed` or `sqlite3.OperationalError: database is locked`, follow these steps:

1. **Kill any conflicting Python processes** that might be holding a lock:
   ```bash
   pkill -f "python.*temp_run.py"
   pkill -f "step2_checkpoint.py"
   pkill -f "python.*download_taiwan_stocks"
   ```

2. **Check if the database file is corrupted**:
   - Try to query the database: if you get "database disk image is malformed", the file is corrupted
   - Look for backup files (e.g., `taiwan_stocks.db.backup_*` or `taiwan_stocks.db.corrupted*`)

3. **Recover from corruption**:
   - If you have a recent backup, copy it over the corrupted file:
     ```bash
     cp taiwan_stocks.db.backup_<timestamp> taiwan_stocks.db
     ```
   - If no backup exists, delete the corrupted file to let the pipeline recreate it:
     ```bash
     rm taiwan_stocks.db
     # The pipeline will recreate the table on next run
     ```
   - You can also attempt to recover using SQLite's backup API (as done in the session):
     ```python
     import sqlite3
     src_conn = sqlite3.connect('corrupted.db')
     dst_conn = sqlite3.connect('recovered.db')
     src_conn.backup(dst_conn)
     src_conn.close()
     dst_conn.close()
     ```

4. **Prevent future locking issues**:
   - Ensure only one instance of the pipeline runs at a time (the cron job schedule helps with this)
   - Avoid reading the database while the pipeline is writing to it
   - For monitoring progress during a run, prefer checking the checkpoint file over querying the database
If you encounter `sqlite3.DatabaseError: database disk image is malformed` or `sqlite3.OperationalError: database is locked`, follow these steps:

1. **Kill any conflicting Python processes** that might be holding a lock:
   ```bash
   pkill -f "python.*temp_run.py"
   pkill -f "step2_checkpoint.py"
   pkill -f "python.*download_taiwan_stocks"
   ```

2. **Check if the database file is corrupted**:
   - Try to query the database: if you get "database disk image is malformed", the file is corrupted
   - Look for backup files (e.g., `taiwan_stocks.db.backup_*` or `taiwan_stocks.db.corrupted*`)

3. **Recover from corruption**:
   - If you have a recent backup, copy it over the corrupted file:
     ```bash
     cp taiwan_stocks.db.backup_<timestamp> taiwan_stocks.db
     ```
   - If no backup exists, delete the corrupted file to let the pipeline recreate it:
     ```bash
     rm taiwan_stocks.db
     # The pipeline will recreate the table on next run
     ```
   - You can also attempt to recover using SQLite's backup API (as done in the session):
     ```python
     import sqlite3
     src_conn = sqlite3.connect('corrupted.db')
     dst_conn = sqlite3.connect('recovered.db')
     src_conn.backup(dst_conn)
     src_conn.close()
     dst_conn.close()
     ```

4. **Prevent future locking issues**:
   - Ensure only one instance of the pipeline runs at a time (the cron job schedule helps with this)
   - Avoid reading the database while the pipeline is writing to it
   - For monitoring progress during a run, prefer checking the checkpoint file over querying the database

### Checkpoint Issues
If the pipeline seems to be reprocessing the same stocks or skipping stocks unexpectedly:

1. **Verify the checkpoint file**:
   ```bash
   cat /opt/data/step2_checkpoint.json
   ```
   Should contain a JSON object with a "processed" list of stock codes.

2. **Rebuild checkpoint from database** (if checkpoint is missing or corrupt):
   ```bash
   cd /opt/data && python3 -c "
   import json, sqlite3
   conn = sqlite3.connect('taiwan_stocks.db')
   c = conn.cursor()
   c.execute('SELECT DISTINCT stock_code FROM daily_prices')
   processed = [row[0] for row in c.fetchall()]
   with open('step2_checkpoint.json', 'w') as f:
       json.dump({'processed': processed}, f)
   print(f'Checkpoint rebuilt with {len(processed)} stocks')
   conn.close()
   ```

### Rate Limiting
If you see HTTP 429 errors or suspect you're being rate-limited:

1. **Increase the wait time** between requests by adjusting the RateLimiter parameters
2. **Verify current rate** - the pipeline targets 40 requests/minute to stay safely under the observed ~60 requests/minute limit
3. **Check for concurrent processes** - multiple instances running simultaneously will compound the request rate

### twstock API Changes
If you see `AttributeError: 'dict' object has no attribute 'codes'` or similar errors:

1. **Update twstock** to the latest version:
   ```bash
   uv pip install --upgrade twstock
   ```
2. The `twstock.codes` attribute is a dict; ensure you are using twstock >= 1.5

### Process Management
If the pipeline appears stuck or is consuming excessive resources:

1. **Identify the process**:
   ```bash
   ps aux | grep -E "(python.*temp_run|step2_checkpoint|download_taiwan_stocks)" | grep -v grep
   ```

2. **Terminate it safely**:
   ```bash
   pkill -f "python.*temp_run.py"
   pkill -f "step2_checkpoint.py"
   pkill -f "python.*download_taiwan_stocks"
   ```

3. **Check the checkpoint and database** to determine how much progress was made before termination
pkill -f "python.*temp_run.py"
pkill -f "step2_checkpoint.py"
```
Then, if the database file is corrupted, restore from the latest backup (e.g., `taiwan_stocks.db.backup_*`) or delete the file to let the pipeline recreate it.

### twstock API Changes
If you see `AttributeError: 'dict' object has no attribute 'codes'`, update twstock to the latest version:
```
uv pip install --upgrade twstock
```
The `twstock.codes` attribute is a dict; ensure you are using twstock >= 1.5.

### Rate Limiting
To avoid being blocked by TWSE, limit requests to no more than 60 per minute. The pipeline uses a RateLimiter class targeting 40 requests per minute for safety.

### Checkpointing
Progress is saved in `/opt/data/step2_checkpoint.json`. If the file is missing, the pipeline will start from the beginning. To resume, ensure the checkpoint file exists and contains a list of processed stock codes.

### 2026-06-07 Completion & Daily Update Setup
- Historical backfill completed: All 1925 Taiwan stocks (TWSE + TPEX) now have complete historical daily data from 2016-03-01 to 2026-06-05
- Historical jobs paused: twse_batch_50per10m and twse_completion_check cron jobs paused after completion
- Daily update job established: New twse_daily_update cron job created to fetch previous trading day data daily at 16:06
### 2026-06-07 Completion & Daily Update Setup
- Historical backfill completed: All 1925 Taiwan stocks (TWSE + TPEX) now have complete historical daily data from 2016-03-01 to 2026-06-05
- Historical jobs paused: twse_batch_50per10m and twse_completion_check cron jobs paused after completion
- Daily update job established: New twse_daily_update cron job created to fetch previous trading day data daily at 16:06

## References
- **Daily Update Procedure**: See `references/daily_update_procedure.md` for details on the established daily update job that keeps the database current after historical backfill completion.
- **Rate Limit Guidelines**: Refer to `references/rate_limits.md` for TWSE API request limits and recommended throttling strategies.
- **Session Learnings**: See `references/session_learnings.md` for operational insights and recommendations based on actual pipeline runs.
- **Progress Reporting**: See `references/progress_reporting.md` for methods to monitor and report download completion percentage.
- **Checkpoint Management**: Refer to `references/checkpoint_management.md` for best practices on saving and restoring progress.
- **Database Locking and Corruption**: See `references/database_troubleshooting.md` for detailed steps to handle SQLite corruption and locking issues.
- **Cron Script Path Resolution**: Refer to `references/cron_script_path_resolution.md` for important notes on script path resolution in Hermes cron jobs.
- **Web Dashboard**: See `references/web_dashboard.md` for details on the Streamlit dashboard for exploring downloaded Taiwan stock data.
- **Web Dashboard**: See `references/web_dashboard.md` for details on the Streamlit dashboard for exploring downloaded Taiwan stock data.\n- **Troubleshooting Database Locks**: See `references/database_troubleshooting.md` for detailed steps to handle SQLite corruption and locking issues.\n- **Rate Limit Guidelines**: Refer to `references/rate_limits.md` for TWSE API request limits and recommended throttling strategies.\n- **Session Learnings**: See `references/session_learnings.md` for operational insights and recommendations based on actual pipeline runs.\n- **Progress Reporting**: See `references/progress_reporting.md` for methods to monitor and report download completion percentage.\n- **Checkpoint Management**: Refer to `references/checkpoint_management.md` for best practices on saving and restoring progress.\n- twstock documentation: https://github.com/mlouielu/twstock\n- TWSE OpenAPI rate limits (historical data): ~60 requests/minute (observed via E‑Sun Securities API as proxy)\n- SQLite UPSERT syntax: `INSERT OR REPLACE`\n- See `references/rate_limits.md` for detailed rate limit observations.\n
## Scripts\n- `scripts/download_taiwan_stocks.py` – main download script with rate limiting and checkpointing.\n- `scripts/session_based_downloader.py` – optimized session-based downloader for cron jobs (processes limited stocks per run).\n- `scripts/verify_db.py` – simple verification script to report row/stock counts and date range.\n\n## Templates\n- `templates/daily_prices_schema.sql` – SQL to create the table and indexes.
