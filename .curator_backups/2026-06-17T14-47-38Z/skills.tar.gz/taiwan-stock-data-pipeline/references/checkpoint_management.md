# Checkpoint Management Best Practices

## Saving Checkpoints
- Save checkpoint immediately after processing each stock (not in batches)
- Use atomic write pattern: write to temp file then rename
- Include timestamp and stock code in checkpoint for debugging
- Validate checkpoint JSON structure on load

## Loading Checkpoints
- Handle missing/corrupt checkpoint gracefully (start from scratch)
- Validate that processed stock codes actually exist in twstock.codes
- Rebuild checkpoint from database if needed (see recovery procedures)
- Log number of stocks loaded from checkpoint

## Checkpoint File Format
```json
{
  "processed": ["2330", "2454", "1216", ...],
  "last_updated": "2026-06-06T23:17:27Z",
  "version": "1.0"
}
```

## Recovery Procedures
If checkpoint is missing or suspect:
1. Query database for distinct stock codes: `SELECT DISTINCT stock_code FROM daily_prices`
2. Compare with expected stock list from twstock
3. Rebuild checkpoint with verified processed stocks
4. Optionally keep old checkpoint as backup before rebuilding

## Avoiding Checkpoint Drift
- Never change start year/month without deleting checkpoint
- If changing date range, treat as fresh start or implement proper migration
- Consider including date range in checkpoint validation