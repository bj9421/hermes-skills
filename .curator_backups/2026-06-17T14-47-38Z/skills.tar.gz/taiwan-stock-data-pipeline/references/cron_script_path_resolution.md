# Cron Script Path Resolution in Hermes

## The Quirk
When configuring a Hermes cron job with:
- `no_agent: true` (runs script directly without LLM)
- `workdir: "/opt/data"` (sets working directory)
- `script: "some_script.sh"` (the script to run)

The actual resolved path is: `{workdir}/scripts/{script}`

## Common Mistakes
❌ Incorrect: `script: "./run_twse_batch.sh"`  
   → Resolves to: `/opt/data/scripts/./run_twse_batch.sh` (still works but unnecessary)

❌ Incorrect: `script: ".hermes/scripts/run_twse_batch.sh"`  
   → Resolves to: `/opt/data/scripts/.hermes/scripts/run_twse_batch.sh` (WRONG - double nesting)

❌ Incorrect: `script: "/opt/data/run_twse_batch.sh"`  
   → Resolves to: `/opt/data/scripts/opt/data/run_twse_batch.sh` (WRONG - absolute path treatment)

✅ Correct: `script: "run_twse_batch.sh"`  
   → Resolves to: `/opt/data/scripts/run_twse_batch.sh` (CORRECT)

## Verification
After creating/updating a cron job, verify the actual script path:
```
hermes cronjob action=list --job_id <your_job_id>
```
Check the `script` and `workdir` fields in the output.

## Best Practice
1. Place your main Python script in workdir: `/opt/data/run_twse_batch.py`
2. Create a simple shell wrapper in workdir/scripts/: `/opt/data/scripts/run_twse_batch.sh`
3. Configure cron job with:
   - `workdir: /opt/data`
   - `script: run_twse_batch.sh`
   - `no_agent: true`

## Shell Wrapper Template
```bash
#!/usr/bin/env bash
cd /opt/data
/opt/hermes/.venv/bin/python /opt/data/run_twse_batch.py
```

## Troubleshooting "Script not found" Errors
If you see errors like:
```
Script not found: /opt/data/scripts/.hermes/scripts/run_twse_batch.sh
```

This indicates you've incorrectly included a relative path prefix in the script value.

Fix: Remove the prefix and use just the script name:
```
hermes cronjob action=update --job_id <job_id> --script "run_twse_batch.sh"
```