# Daily Update Procedure for Taiwan Stock Data

## Overview
After completing the historical backfill of all Taiwan stock data (TWSE + TPEX), a daily update job was established to keep the database current with the latest trading day's data.

## Job Configuration
- **Job ID**: `d8379e951943`
- **Name**: `twse_daily_update`
- **Schedule**: `6 16 * * *` (daily at 16:06)
- **Script**: `run_twse_daily_update.sh`
- **Workdir**: `/opt/data`
- **No Agent**: `true` (direct script execution)

## Script Logic
The daily update script (`run_twse_daily_update.py`) performs the following:

1. **Target Date**: Updates data for the previous trading day (to ensure data is published)
   - Uses `datetime.now() - timedelta(days=1)` 
   - Note: Simple weekend subtraction - will attempt to fetch Sat/Sun data (which will return no data)

2. **Process**:
   - Updates TWSE/TPEX code lists
   - For each stock, fetches data for the target month
   - Filters to only the target date's data
   - Upserts into `daily_prices` table using `INSERT OR REPLACE`
   - Commits after all stocks are processed

3. **Rate Limiting**: ~55 requests/minute (~1.09s between requests)

4. **Error Handling**:
   - Continues processing when individual stocks fail
   - Reports stocks with no data (holidays, suspensions)
   - Logs any exceptions encountered

## Expected Output
When run successfully, the script outputs:
```
Updating stock data for YYYY-MM-DD (previous day)
Total stocks: 1925
  [stock_code]: 無資料 (可能為非交易日)  [for non-trading days/stocks]
  ...
=== 更新完成 ===
  成功更新: [count] 支股票
  跳過/無資料: [count] 支股票
  耗時: [seconds] 秒
```

## Verification
To verify the daily update worked:
```bash
cd /opt/data && python3 -c "
import sqlite3
conn = sqlite3.connect('taiwan_stocks.db')
c = conn.cursor()
c.execute('SELECT MAX(date) FROM daily_prices')
print('Latest date in DB:', c.fetchone()[0])
c.execute('SELECT COUNT(DISTINCT stock_code) FROM daily_prices WHERE date = (SELECT MAX(date) FROM daily_prices)')
print('Stocks with latest date:', c.fetchone()[0])
conn.close()
"
```

## Maintenance
- The job runs automatically every day at 16:06
- To manually trigger: `/opt/data/scripts/run_twse_daily_update.sh`
- To check last run: `hermes cronjob action=list` and look for `twse_daily_update`
- To pause/resume: Use `hermes cronjob action=pause/resume job_id=d8379e951943`

## Notes
- The 16:06 timing ensures previous day's data is available (TWSE typically publishes data shortly after market close)
- Stocks that don't trade on a given day (weekends, holidays, suspensions) will show as "無資料" which is expected
- The `INSERT OR REPLACE` pattern ensures that if data is updated later (corrections), it will be properly reflected