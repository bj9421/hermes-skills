# Progress Reporting for Taiwan Stock Data Pipeline

## User Preferences
Based on direct feedback during pipeline operations:
- **Language**: Provide progress updates in both English and Chinese
- **Frequency**: Regular updates via cron job output (every 10 minutes in this implementation)
- **Content**: Include batch-specific information and overall progress percentage
- **Format**: Clear, structured output that's easy to parse visually

## Progress Output Format
The pipeline outputs progress in this bilingual format:
```
本次將處理 X 支股票（剩餘 Y 支）
  [STOCK_CODE]: 寫入/更新 Z 筆
  [STOCK_CODE]: 寫入/更新 Z 筆
  ...
  ⏰ 時間預算將盡 (Ts)，提前結束本批次   (optional, when time budget exceeded)
=== 進度回報：已處理 A/B 支股票 (C%) ===
```

Where:
- X: Number of stocks being processed in current batch
- Y: Number of stocks remaining to be processed
- Z: Number of records inserted/updated for each stock
- T: Elapsed time when time budget was exceeded (if applicable)
- A: Total number of stocks processed so far
- B: Total number of stocks (~1925 for TWSE+TPEX)
- C: Completion percentage (A/B * 100)

## Implementation Details

### Progress Calculation
Progress percentage is calculated from the checkpoint file:
```python
import json
from pathlib import Path

checkpoint_path = Path('/opt/data/step2_checkpoint.json')
if checkpoint_path.exists():
    with open(checkpoint_path) as f:
        data = json.load(f)
        processed_count = len(data.get('processed', []))
else:
    processed_count = 0

total_stocks = 1925  # Approximate total TWSE+TPEX stocks
percentage = (processed_count / total_stocks) * 100
```

### Cron Job Output
When using `no_agent: true` cron jobs, the script's stdout is delivered directly to the user. The script prints:
1. Batch header: `本次將處理 X 支股票（剩餘 Y 支）`
2. Per-stock results as they're processed
3. Time budget warning (if applicable)
4. Final progress report: `=== 進度回報：已處理 A/B 支股票 (C%) ===`

### Example Output
From actual pipeline runs:
```
本次將處理 36 支股票（剩餘 284 支）
  1623: 寫入/更新 86 筆
  6907: 寫入/更新 81 筆
  6961: 寫入/更新 86 筆
  5547: 寫入/更新 78 筆
  2072: 寫入/更新 49 筆
  7792: 寫入/更新 82 筆
  6423: 寫入/更新 86 筆
  7811: 寫入/更新 50 筆
  5547: 寫入/更新 78 筆
=== 進度回報：已處理 1655/1925 支股票 (85.9%) ===
```

## Best Practices
1. **Flush output immediately**: Use `sys.stdout.flush()` after print statements to ensure timely delivery in cron environments
2. **Handle interruptions gracefully**: Wrap output in try/except to prevent output errors from crashing the script
3. **Include meaningful identifiers**: Always show stock codes so users can see exactly what's being processed
4. **Show work done**: Display record counts so users can verify data is being downloaded correctly
5. **Time budget awareness**: Inform users when processing stops early due to time constraints
6. **Clear completion marker**: Use distinct markers (=== ===) to make progress reports easy to spot in logs

## Troubleshooting Progress Reporting
If progress reports aren't appearing as expected:
1. Check that `sys.stdout.flush()` is being called after print statements
2. Verify the script isn't crashing before reaching the progress reporting code
3. Ensure checkpoint file is being read correctly for processed count
4. Confirm total_stocks value is appropriate for your market (1925 is TWSE+TPEX approximation)