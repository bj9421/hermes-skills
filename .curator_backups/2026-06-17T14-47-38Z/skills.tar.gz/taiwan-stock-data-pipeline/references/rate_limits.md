# Rate Limits and Throttling for TWSE API

## Observed Limits
Based on empirical testing during pipeline operations:
- TWSE/TPEX historical data API allows approximately **60 requests per minute**
- Exceeding this limit results in HTTP 429 errors or connection issues
- The pipeline uses a conservative rate limit of **40 requests per minute** (1.5 seconds between requests) to provide a safety buffer

## Rate Limiter Implementation
The pipeline uses a `RateLimiter` class that:
- Tracks time between requests
- Enforces minimum interval (`min_interval`) between consecutive requests
- Sleeps if necessary to maintain the rate limit
- Resets the timer after each request (whether successful or failed)

```python
class RateLimiter:
    def __init__(self, min_interval=1.5):
        self.min_interval = min_interval
        self._last = 0.0
    
    def wait(self):
        now = time.time()
        elapsed = now - self._last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self._last = time.time()
```

## Configuration
- Default `MIN_INTERVAL = 1.5` seconds (40 requests/minute)
- Can be adjusted based on observed API behavior
- Higher values (longer intervals) are safer but slower
- Lower values (shorter intervals) risk hitting rate limits

## Troubleshooting Rate Limit Issues
If you encounter:
1. **HTTP 429 errors**: Increase `MIN_INTERVAL` (e.g., to 2.0 seconds for 30 rpm)
2. **Frequent timeouts or connection errors**: May indicate rate limiting or network issues
3. **Inconsistent data**: Could be due to interrupted requests from rate limiting

## Best Practices
1. Start conservative (40 rpm) and only increase if you have evidence the API allows more
2. Monitor for any 429 responses in logs
3. Consider implementing exponential backoff for 429 errors
4. Remember that rate limits apply across all instances - don't run multiple pipeline instances simultaneously without adjusting rates

## Historical Data Specifics
- Historical data endpoints tend to be more rate-limited than real-time quotes
- Each request fetches months of data, so fewer requests are needed overall
- The 1.5 second interval has proven reliable for extended runs