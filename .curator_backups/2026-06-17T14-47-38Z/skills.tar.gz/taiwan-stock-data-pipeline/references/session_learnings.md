# Session Learnings: Taiwan Stock Data Pipeline (2026-06-06, 2026-06-07)

## Key Learnings from Debugging Cron Job Failures

### 1. Cron Script Path Resolution Quirk
When using Hermes cron with `no_agent=true` and a specified `workdir`:
- The `script` parameter resolves relative to `{workdir}/scripts/`
- Do NOT use relative paths like `./` or `.hermes/scripts/` prefixes
- Correct: `script: "run_twse_batch.sh"` with `workdir: "/opt/data"` → resolves to `/opt/data/scripts/run_twse_batch.sh`
- Incorrect: `script: ".hermes/scripts/run_twse_batch.sh"` → resolves to `/opt/data/scripts/.hermes/scripts/run_twse_batch.sh` (doesn't exist)

### 2. Timeout Management Strategy
Stock data fetching from TWSE takes ~20-25 seconds per stock (2023-present data) plus rate limiting.
- Default Hermes cron timeout is 120 seconds for `no_agent` jobs
- Leave 10-20 seconds buffer for checkpoint writes and overhead
- Calculate batch size from time budget: `BATCH_SIZE = max(1, int(TIME_BUDGET_SEC / ESTIMATED_SEC_PER_STOCK))`
- For 100-second time budget and 30-second estimate per stock: ~3 stocks per batch
- For 150-second time budget and 20-second estimate per stock: ~7 stocks per batch
- Add early-stop guard in processing loop to respect time budget

### 3. Robust Error Handling
Both `Stock()` constructor and `fetch_from()` can fail:
- Wrap `Stock()` construction in try/except for initialization failures (e.g., TooManyRedirects)
- Wrap `fetch_from()` in try/except for network/API errors
- Continue processing other stocks when individual stocks fail
- Mark failed stocks as "processed" in checkpoint to avoid infinite retry loops

### 4. Intelligent Retry Mechanism
Track retry counts to prevent endless retries on permanently problematic stocks:
- Only retry stocks with < 100 records in database (likely incomplete downloads)
- Limit retries to 3 attempts per stock
- After 3 failed attempts, treat as permanently problematic and move on
- Store retry counts in a separate JSON file (`step2_retry_counter.json`)

### 5. Progress Reporting Preferences
User prefers bilingual progress updates (English + Chinese) showing:
- Number of stocks being processed in current batch
- Remaining stock count
- Records inserted/updated per stock
- Final progress percentage after each run
- Format: `本次將處理 X 支股票（剩餘 Y 支）` followed by per-stock results and `=== 進度回報：已處理 A/B 支股票 (C%) ===`

### 6. Verification After Completion
After pipeline finishes, verify data integrity with:
- Total row count and distinct stock count
- Date range validation
- Spot-check for NULL values and price logic errors
- Check for stocks with unusually low record counts (newly listed stocks)

## Implementation Status Updates

### 2026-06-06 Implementation:
- All learnings from this session have been successfully implemented and tested:
  - Cron timeout increased to 180 seconds via `hermes config set cron.script_timeout_seconds 180`
  - Python script updated with time budget approach (100 seconds) and dynamic batch sizing (~3 stocks/batch)
  - Added intelligent retry mechanism with `step2_retry_counter.json` to limit retries on problematic stocks
  - Enhanced error handling to catch both `Stock()` constructor and `fetch_from()` failures
  - Progress reporting maintains bilingual format as per user preference
  - Verified no more timeout errors in cron job execution
  - Pipeline now processes stocks reliably with automatic resumability and checkpointing

### 2026-06-07 Optimization:
- Increased timeout utilization: adjusted script time budget from 100s to 150s (leveraging the 180s cron limit)
- Improved throughput: reduced MIN_INTERVAL from 1.5s to 1.09s (~55 requests/minute from ~40 requests/minute)
- Enhanced batch size: increased from ~3 stocks/batch to ~7 stocks/batch
- Maintained reliability: kept intelligent retry mechanism and robust error handling
- Verified performance: processing rate increased from ~3 to ~7 stocks per 10-minute cron cycle
- Current status: pipeline processes stocks efficiently with automatic resumability and checkpointing