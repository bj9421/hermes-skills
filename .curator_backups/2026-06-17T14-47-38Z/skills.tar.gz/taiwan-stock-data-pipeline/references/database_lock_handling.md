# Handling SQLite Database Locks During Taiwan Stock Pipeline Monitoring

## Problem
When monitoring the progress of the Taiwan stock historical data download pipeline, attempting to query the SQLite database (`/opt/data/taiwan_stocks.db`) while the download script is running often results in "database is locked" errors. This occurs because SQLite uses file-level locking and the download script holds a write lock.

## Observed Errors During This Session
- `sqlite3.OperationalError: database is locked`
- `sqlite3.OperationalError: database disk image is malformed` (when trying to copy the database mid-transaction)

## Solutions and Workarounds

### 1. Primary: Use Checkpoint File for Progress Monitoring
The most reliable method during active download is to read the JSON checkpoint file:
```python
import json
with open('/opt/data/step2_checkpoint.json', 'r') as f:
    checkpoint = json.load(f)
processed_count = len(checkpoint.get('processed', []))
processed_stocks = checkpoint.get('processed', [])
```

### 2. Read-Only Connection with Retry Logic
For read-only queries that can tolerate occasional failures:
```python
import sqlite3
import time

def query_with_retry(db_path, query, params=(), max_retries=5, delay=2):
    for i in range(max_retries):
        try:
            conn = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=5.0)
            cursor = conn.cursor()
            cursor.execute(query, params)
            result = cursor.fetchall()
            conn.close()
            return result
        except sqlite3.OperationalError as e:
            if 'locked' in str(e).lower() and i < max_retries - 1:
                time.sleep(delay)
                continue
            else:
                raise
    raise Exception(f"Failed after {max_retries} retries")

# Usage:
# rows = query_with_retry('/opt/data/taiwan_stocks.db', 
#                        "SELECT COUNT(*) FROM daily_prices")
```

### 3. Safe Database Copying (with Validation)
If a full copy is needed, validate it after copying:
```python
import shutil
import sqlite3

def safe_db_copy(source_path, dest_path):
    # Copy the database file
    shutil.copy2(source_path, dest_path)
    
    # Validate the copy
    try:
        conn = sqlite3.connect(dest_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM daily_prices")
        count = cursor.fetchone()[0]
        conn.close()
        return True, count
    except sqlite3.OperationalError as e:
        if 'malformed' in str(e).lower():
            return False, f"Database copy is malformed: {e}"
        raise
```

### 4. Alternative: Separate Reporting Database
For production monitoring, consider:
- Using a separate read-replica database that gets updated periodically
- Implementing a logging mechanism that writes progress to a separate file/table
- Using WAL (Write-Ahead Logging) mode for better concurrency (requires modifying the pipeline)

## When to Use Which Approach
- **During active download**: Use checkpoint file (100% reliable)
- **Lightweight monitoring during download**: Read-only with retry (may have occasional failures)
- **Post-download verification or scheduled reporting**: Direct queries or validated copies
- **Production systems**: Consider separate reporting database or WAL mode

## References
- SQLite locking: https://www.sqlite.org/lockingv3.html
- SQLite WAL mode: https://www.sqlite.org/wal.html
- File-based locking caveats: https://www.sqlite.org/faq.html#q5