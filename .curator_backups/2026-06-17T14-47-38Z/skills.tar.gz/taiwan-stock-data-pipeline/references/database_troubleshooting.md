# Database Troubleshooting for Taiwan Stock Data Pipeline

## Common Issues

### 1. Database Locked
**Error**: `sqlite3.OperationalError: database is locked`
**Cause**: Another process is holding a lock on the database file.
**Solution**:
- Identify and kill any lingering Python processes using the database:
  ```bash
  pkill -f "python.*temp_run.py"
  pkill -f "step2_checkpoint.py"
  ```
- Wait a few seconds and retry.

### 2. Malformed Database Disk Image
**Error**: `sqlite3.DatabaseError: database disk image is malformed`
**Cause**: The SQLite database file has become corrupted, often due to abrupt termination during a write.
**Solution**:
- Restore from the latest backup (if available):
  ```bash
  cp /opt/data/taiwan_stocks.db.backup_* /opt/data/taiwan_stocks.db
  ```
- If no backup exists, delete the corrupted file and let the pipeline recreate it:
  ```bash
  rm /opt/data/taiwan_stocks.db
  ```
  The pipeline will create a new database on the next run.

### 3. Checkpoint File Missing or Corrupted
**Error**: `FileNotFoundError` or `JSONDecodeError` when reading `/opt/data/step2_checkpoint.json`
**Solution**:
- If missing, the pipeline will start from the beginning (no major issue).
- If corrupted, delete the file and let the pipeline create a new one:
  ```bash
  rm /opt/data/step2_checkpoint.json
  ```

## Prevention
- Always allow the pipeline to finish its current batch before interrupting.
- Use the provided cron job to manage runs; avoid manual concurrent executions.
- Monitor disk space; a full disk can cause corruption during writes.

## Verification
After recovering, you can verify the database integrity with:
```bash
sqlite3 /opt/data/taiwan_stocks.db "PRAGMA integrity_check;"
```
It should return `ok` if the database is healthy.