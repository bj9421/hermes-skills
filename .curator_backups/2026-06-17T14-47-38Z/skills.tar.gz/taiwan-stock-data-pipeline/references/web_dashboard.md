# Web Dashboard for Taiwan Stock Data Exploration

## Overview
A lightweight Streamlit dashboard has been deployed to explore the downloaded Taiwan stock data stored in the SQLite database. This dashboard provides an interactive interface for browsing and analyzing stock data without needing to write SQL queries.

## Features

### 1. Industry Filtering
- Dropdown menu to filter stocks by sector/industry (e.g., 電子類, 食品類, 金融類, 建材類, etc.)
- Industries are derived from the stock classification in the `twstock.codes` dataset

### 2. Daily Stock Overview
- For the selected industry, displays all stocks with their most recent trading day data
- Columns shown: 股票代碼, 股票名稱, 收盤價, 漲跌幅 (%), 成交量, 成交金額, 振幅 (%)
- Data is sorted by stock code for easy browsing

### 3. Individual Stock Analysis
- Select any stock from the list to view detailed information
- Interactive price chart showing:
  - Daily closing prices over time
  - 5-day and 20-day moving averages (MA5, MA20)
- Volume bar chart below the price chart
- Date range selector for customizing the chart period

### 4. Data Source
- Reads directly from `/opt/data/taiwan_stocks.db` SQLite database
- Queries the `daily_prices` table which contains OHLCV data
- Automatically reflects updates from the daily update cron job

## Technical Implementation

### Dependencies
- `streamlit`: Web framework for creating the dashboard
- `pandas`: Data manipulation and analysis
- `plotly`: Interactive charting library
- `sqlite3`: Built-in Python module for database access

### File Location
- Dashboard script: `/opt/data/dashboard.py`
- Data database: `/opt/data/taiwan_stocks.db`

### How It Works
1. On load, the dashboard connects to the SQLite database
2. Retrieves list of available industries from stock metadata
3. When an industry is selected:
   - Queries for all stocks in that industry
   - For each stock, fetches the most recent trading day record
   - Displays the summary table
4. When a stock is selected for detailed view:
   - Retrieves historical data for that stock
   - Calculates moving averages
   - Renders interactive charts using Plotly

## Deployment & Usage

### Starting the Dashboard
```bash
cd /opt/data
/opt/hermes/.venv/bin/streamlit run dashboard.py --server.port 8501
```

### Accessing the Dashboard
Once running, access the dashboard at:
- `http://<your_raspberry_pi_ip>:8501`
- Example: `http://localhost:8501` or `http://192.168.x.x:8501`

### Stopping the Dashboard
```bash
pkill -f "streamlit run dashboard.py"
```

### Background Deployment
The dashboard has been deployed as a background process using Hermes terminal tool with:
- `background=true`
- `notify_on_complete=true`
- Running on port 8501

## Customization

### Changing the Port
To run on a different port, modify the `--server.port` argument:
```bash
/opt/hermes/.venv/bin/streamlit run dashboard.py --server.port 8080
```

### Adjusting Refresh Rate
The dashboard does not automatically refresh - users must manually refresh the browser to see new data from the database. This design choice prevents unnecessary database load during active viewing.

## Data Freshness
- The dashboard shows whatever data is currently in the database
- Data freshness depends on the daily update cron job (runs at 16:06 daily)
- For intraday data, the dashboard would need to be connected to a real-time data source

## Troubleshooting

### Common Issues
1. **Dashboard won't start**: 
   - Check if port 8501 is already in use
   - Verify Streamlit is installed: `/opt/hermes/.venv/bin/pip list | grep streamlit`

2. **No data showing**:
   - Verify the database file exists: `ls -la /opt/data/taiwan_stocks.db`
   - Check if the database contains data: `sqlite3 /opt/data/taiwan_stocks.db "SELECT COUNT(*) FROM daily_prices;"`

3. **Slow performance**:
   - Large date ranges in the stock detail view can slow down chart rendering
   - Consider limiting the date range using the date selector

### Logs & Monitoring
Streamlit outputs logs to the terminal where it was started. When deployed as a background process via Hermes, these logs are captured in the process output and can be retrieved using:
```bash
hermes process action=log --session_id <session_id>
```