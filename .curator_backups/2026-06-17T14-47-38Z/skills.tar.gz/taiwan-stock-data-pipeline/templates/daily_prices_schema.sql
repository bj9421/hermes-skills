CREATE TABLE IF NOT EXISTS daily_prices (
    date TEXT NOT NULL,
    stock_code TEXT NOT NULL,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,
    turnover REAL,
    transaction_count INTEGER,
    amplitude REAL,
    PRIMARY KEY (date, stock_code)
);
CREATE INDEX IF NOT EXISTS idx_stock ON daily_prices(stock_code);
CREATE INDEX IF NOT EXISTS idx_date ON daily_prices(date);