#!/usr/bin/env bash
# Shell wrapper for no_agent cron mode.
# Cron resolves --script relative to workdir/scripts/.
# This wrapper lives at e.g. /opt/data/scripts/run_twse_batch.sh
cd /opt/data
/opt/hermes/.venv/bin/python /opt/data/run_twse_batch.py