---
name: ai-stock-screener
description: Use when launching the Taiwan Stock Cashflow Analysis API server (taiwan-stock-cashflow-api). Provides startup, health check, and basic usage guidance.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [taiwan-stock, cashflow, api, screener, stocks]
    related_skills: [taiwan-stock-data-pipeline]
---

# AI 選股 - 台股現金流分析 API

## Overview

本技能用於啟動與操作 `/opt/data/taiwan-stock-cashflow-api` 專案，這是一個提供台灣上市公司現金流及財務分析的本地 API 伺服器。

## When to Use

- 需要啟動台股現金流分析 API 伺服器時
- 需要檢查伺服器運行狀態時
- 需要查詢特定股票財務分析資料時

## Project Structure

```
/opt/data/taiwan-stock-cashflow-api/
├── app.py                  # 主應用程式 (Flask)
├── financial_analyzers.py  # 財務分析模組
├── batch_scan.py           # 批次掃描腳本
├── daily_push.py           # 每日推播功能
├── start_server.py         # 啟動腳本
├── restart_server.py       # 重啟腳本
├── requirements.txt
├── taiwan_stocks.db        # 台股資料庫
└── screening/              # 選股邏輯資料夾
```

## Quick Start

### 1. 啟動伺服器

```bash
cd /opt/data/taiwan-stock-cashflow-api
source .venv/bin/activate
python app.py
```

伺服器預設運行於 `http://localhost:5000`

### 2. 確認伺服器狀態

```bash
curl http://localhost:5000/
```

預期回應：
```json
{
  "message": "現金流分析 API (支持年度累計資料)",
  "usage": "/analyze/<stock_code>",
  "version": "1.2"
}
```

### 3. 分析股票

```bash
# 分析台積電 (2330)
curl http://localhost:5000/analyze/2330

# 分析鴻海 (2317)
curl http://localhost:5000/analyze/2317
```

## API Endpoints

| 端點 | 說明 | 範例 |
|------|------|------|
| `GET /` | 伺服器狀態 | `curl localhost:5000/` |
| `GET /analyze/<code>` | 分析指定股票現金流 | `curl localhost:5000/analyze/2330` |

## Common Pitfalls

1. **虛擬環境未啟動**：執行前務必 `source .venv/bin/activate`
2. **埠號衝突**：預設使用 5000 port，若被佔用需修改 `app.py`
3. **資料庫遺失**：`taiwan_stocks.db` 必須存在於專案根目錄
4. **背景執行**：若要在背景執行，使用 `background=true` 參數

## 同步到 Obsidian

若要將此技能的文件同步到 Obsidian Vault：

```
/opt/data/obsidian-vault/技能筆記/
```

### 注意事項
- `Hermes/` 目錄由 user `1000` 擁有，直接寫入會有權限問題
- 請使用 `技能筆記/` 目錄（hermes 用戶可寫入）
- 必要時可手動將檔案移至 `Hermes/` 目錄

## Verification Checklist

- [ ] 確認虛擬環境已啟動
- [ ] `curl localhost:5000/` 回傳預期 JSON
- [ ] `curl localhost:5000/analyze/2330` 回傳分析結果
- [ ] `server.log` 無錯誤訊息
