---
name: dashboard-web-debugging
description: "Debug web dashboard issues: API endpoints, JS errors, CORS, fetch patterns, Canvas/D3 rendering, and Flask frontend-backend integration."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [debugging, dashboard, web, flask, javascript, canvas, d3]
---

# Dashboard Web Debugging

## Overview

Debug web dashboards where a Flask/Python backend serves a static HTML/JS frontend. Covers API issues, JavaScript errors, Canvas/D3 rendering bugs, and frontend-backend data flow problems.

## Common Pitfalls

### 1. fetchWithTimeout Returns Parsed JSON, Not Response Object

When a custom `fetchWithTimeout` helper resolves with `.json()`, the return value is a **parsed JSON object**, not a `Response` object.

```javascript
// WRONG — .ok and .json() don't exist on JSON objects
if (res.ok) { const data = await res.json(); ... }

// CORRECT — check the JSON structure directly
if (res && res.success) { const data = res.data; ... }
```

**Symptoms:** `undefined` appearing in UI, silent failures, entire sections blank.
**Debug:** `console.log(typeof res, res)` — if it's `"object"` but has no `.ok` / `.status`, it's already parsed JSON.

### 2. Canvas API Compatibility

Older browsers (especially mobile Safari) don't support newer Canvas methods:

```javascript
// roundRect is 2021+, may not be available on older browsers
ctx.roundRect(...); // CRASH

// Safe pattern: try-catch fallback
try {
  ctx.roundRect(x, y, w, h, r);
} catch(e) {
  ctx.rect(x, y, w, h);
}
```

**Always check browser compatibility** before using newer Canvas APIs. Test on mobile Safari specifically.

### 3. API Route Not Registered

Flask returns 404 for valid endpoints when routes are defined but not registered:

```python
# Defined in screener_api.py but never called in app.py
from screening.screener_api import register_screener_routes
register_screener_routes(app)  # ← Must call this!
```

**Debug:** `curl http://localhost:5000/endpoint` — if 404, check route registration.

### 4. Missing Null Safety

Frontend crashes when API returns unexpected structure:

```javascript
// WRONG — no null check
stratRes.strategies.forEach(s => { ... });  // CRASH if stratRes is null

// CORRECT — guard against null
if (stratRes && stratRes.strategies) {
  stratRes.strategies.forEach(s => { ... });
}
```

### 5. Health Endpoint Returns Empty Body

A health check that only returns `{"status": "healthy"}` gives frontend no data to display. Always include structured `error_monitor` or equivalent:

```python
# Good health endpoint
return jsonify({
    "status": "healthy",
    "timestamp": datetime.now().isoformat(),
    "error_monitor": {
        "total_errors": 0,
        "alerts_triggered": 0,
        "latest_data_date": latest,
        "latest_data_rows": rows
    }
})
```

### 6. Date Formatting in Frontend

`toLocaleString('zh-TW')` uses 12-hour format by default. For 24-hour:

```javascript
// 12-hour (default)
new Date(ts).toLocaleString('zh-TW')  // "下午11:34:10"

// 24-hour
new Date(ts).toLocaleString('zh-TW', {
  hour: '2-digit', minute: '2-digit', second: '2-digit',
  hour12: false
})  // "23:34:10"
```

## Debugging Workflow

### Step 1: Check Backend API First

```bash
curl http://localhost:5000/health
curl http://localhost:5000/api/heatmap
curl http://localhost:5000/screen/strategies
```

If API returns 404 or wrong data → fix backend first.

### Step 2: Check Browser Console

```javascript
// In browser DevTools console:
console.log(window.location.origin);  // Check API base
fetch('/health').then(r => r.json()).then(d => console.log(d));
```

Look for:
- `Uncaught TypeError: Cannot read properties of null`
- `undefined` in rendered UI
- CORS errors
- Network failures

### Step 3: Verify Frontend Data Binding

Check that frontend variables match backend JSON structure:
- `res.ok` → should be `res.success` (if fetch helper parses JSON)
- `res.data` → check nested keys match API response
- Array lengths → handle empty arrays gracefully

### Step 4: Test on Target Device

Mobile browsers differ from desktop:
- Canvas API support varies
- Touch events vs click events
- Screen size affects layout calculations
- Always test on the actual target device

## Tools Reference

| Tool | Purpose |
|------|---------|
| `curl` | Test API endpoints directly |
| `browser_console` | Check JS errors and logs |
| `browser_vision` | Visual verification of rendered UI |
| `read_file` | Inspect frontend JS/HTML |
| `search_files` | Find function definitions and API routes |
