# Agnes Provider: Model Deprecation (2026-07-13)

## Timeline

1. `agnes-2.0-flash` started returning **HTTP 404** — `NotFoundError: OpenAIException - {"detail":"Not Found"}`
2. User checked the [Agnes console](https://apihub.agnes-ai.com) and confirmed active models:
   - `agnes-1.5-flash` (chat, successor)
   - `agnes-video-v2.0`
   - `agnes-image-2.1-flash`
   - `agnes-image-2.0-flash`
3. User also wanted `agnes-2.0-flash` kept in the menu (it still works intermittently for some endpoints)

## Config Migration

**Before** (single-model + inline api_key):
```yaml
custom_providers:
  - name: agnes
    base_url: https://apihub.agnes-ai.com/v1/chat/completions
    api_key: sk-X7d...V04F       # plain text, truncated by Hermes display
    api_mode: chat_completions
    model: agnes-2.0-flash        # single model, no menu selection
```

**After** (multi-model + key_env):
```yaml
custom_providers:
  - name: agnes
    base_url: https://apihub.agnes-ai.com/v1/chat/completions
    key_env: AGNES_API_KEY        # reads from .env
    api_mode: chat_completions
    models:
      agnes-2.0-flash:
        context_length: 256000
      agnes-1.5-flash:
        context_length: 256000
      agnes-video-v2.0:
        context_length: 256000
      agnes-image-2.1-flash:
        context_length: 256000
      agnes-image-2.0-flash:
        context_length: 256000
```

## Key Facts

- **Agnes API endpoint:** `https://apihub.agnes-ai.com/v1/chat/completions`
- **API key length:** 13 chars on display (truncated by Hermes `...` masking); actual length ≈ 50+ chars
- **key_env vs api_key:** Use `key_env: AGNES_API_KEY` to read from `.env` — the inline `api_key:` value is masked/truncated by Hermes's display layer but the gateway reads the real value from `.env` directly
- **Fallback providers** also needed updating: `agnes-2.0-flash` → `agnes-1.5-flash` in the `fallback_providers:` list
- **Both profiles** (default + research) need the same changes applied separately

## Error Signatures

| Error | Meaning |
|-------|---------|
| HTTP 404 `NotFoundError: {"detail":"Not Found"}` | Model name deprecated/renamed by provider |
| HTTP 401 `无效的令牌` (invalid token) | API key wrong or expired |
| HTTP 401 `Missing Authentication Header` | Provider routing issue (bare `provider: custom` remapped) |

## `/model` Selector

After migrating to multi-model `models:` dict, the `/model` command shows all models as selectable options. Switch mid-session with:

```
/model custom:agnes:agnes-1.5-flash
/model custom:agnes:agnes-video-v2.0
```
