---
name: hermes-provider-config
description: "Configure any LLM provider in Hermes Agent — built-in env-var providers, single custom endpoints, and named custom providers with key_env pattern. Covers Docker environments without CLI access."
metadata:
  hermes:
    tags: [hermes, providers, custom-endpoint, configuration, docker]
    related_skills: [hermes-agent, hermes-global-config, hermes-env-troubleshooting]
---

# Hermes Provider Configuration

Configure LLM providers: built-in (env-var), single custom endpoint, or named custom providers.

---

## Built-in (Env-Var) Providers

These providers auto-discover when the env var is set. Use `hermes model` (interactive wizard) or `hermes auth add <provider>` for OAuth.

| Provider | Env Var | CLI method |
|----------|---------|------------|
| OpenRouter | `OPENROUTER_API_KEY` | `hermes model` |
| Anthropic API | `ANTHROPIC_API_KEY` | `hermes model` |
| OpenAI API | `OPENAI_API_KEY` | `hermes model` |
| xAI / Grok API | `XAI_API_KEY` | `hermes model` |
| DeepSeek | `DEEPSEEK_API_KEY` | `hermes model` |
| Google Gemini | `GOOGLE_API_KEY` / `GEMINI_API_KEY` | `hermes model` |
| HuggingFace | `HF_TOKEN` | `hermes model` |
| OpenCode Zen | `OPENCODE_ZEN_API_KEY` | `hermes model` |
| OpenCode Go | `OPENCODE_GO_API_KEY` | `hermes model` |

## Single Custom Endpoint

For OpenAI-compatible APIs not covered by built-in support:

```bash
hermes model
# → "Custom endpoint (self-hosted / VLLM / etc.)"
# → Base URL (e.g. https://api.groq.com/openai/v1)
# → API key
# → Model name
```

Or in `config.yaml`:

```yaml
model:
  default: <model-name>
  provider: custom
  base_url: https://api.groq.com/openai/v1
  api_key: gsk_<your-key>
  context_length: 131072       # Optional; min 64K for agent use
```

Mid-session switch: `/model custom:<model-name>`
Auto-detect: `/model custom` (queries /v1/models if only one model)

## Named Custom Providers (Multiple Endpoints)

When you have multiple custom endpoints and need to switch between them:

```yaml
custom_providers:
  - name: groq
    base_url: https://api.groq.com/openai/v1
    key_env: GROQ_API_KEY          # Reads from process env
    api_mode: chat_completions
    models:
      llama-3.3-70b-versatile:
        context_length: 131072
      mixtral-8x7b-32768:
        context_length: 32768

  - name: local
    base_url: http://localhost:11434/v1
    # No api_key or key_env → sends "no-key-required"
    api_mode: chat_completions
```

Switch mid-session: `/model custom:groq:llama-3.3-70b-versatile`

**Fields:**
- `name` — alias used in `custom:<name>` syntax
- `base_url` — endpoint URL (include `/v1`)
- `key_env` — env var name containing the API key (omit for keyless servers)
- `api_mode` — `chat_completions` (OpenAI-compatible) or `anthropic_messages` (Anthropic-compatible proxies)
- `extra_body` — optional dict merged into every request body
- `models.<id>.context_length` — per-model context override

## Verification Checklist

After adding a custom provider, always verify BOTH sides match:

```bash
# 1. Check what provider is configured as default
hermes config show | grep "Model:"

# 2. Verify the custom_providers list includes the registered name
# IMPORTANT: Only check the ACTIVE config (hermes config path) — custom_providers
# in .hermes/config.yaml or profile configs are NOT visible to the model selector
ACTIVE_CFG=$(hermes config path)
[ -f "$ACTIVE_CFG" ] && grep -A20 "custom_providers:" "$ACTIVE_CFG" | grep "name:"

# 3. Test with a quick chat
hermes chat "Hello, what provider are you using?"
```

If step 1 says `provider: custom:foo` but step 2 shows no `name: foo` in `custom_providers:`, the provider is UNREGISTERED — fix by adding the entry.

## Model Lifecycle: Provider Deprecated a Model

When a custom provider model suddenly returns **HTTP 404** (`NotFoundError`), the model name has likely been deprecated or renamed by the provider. This is **not** a config typo — the upstream API no longer serves that model slug.

**Diagnosis:**
```
# In errors.log you'll see:
error_type=NotFoundError
provider=custom:agnes
model=agnes-2.0-flash
summary=HTTP 404: NotFoundError - {"detail":"Not Found"}
```

vs a real auth error (401) or key issue (still returns a reachable error shape).

**Fix procedure:**
1. **Check the provider's actual model list** — visit their console or make a GET to their models endpoint
2. **Update the model name in two places**:
   - `custom_providers[].models` dict (add new name, keep old one if it still sometimes works)
   - `fallback_providers[]` entry if it references the old name
3. **Single-model → multi-model migration** (see section below) — if you were using the old `model:` field, this is the time to switch to the `models:` dict format

## Single-Model → Multi-Model Migration

Named custom providers can be defined in two formats. The old format uses a single `model:` field; the new format uses a `models:` dict with per-model `context_length`.

**Old (single model):**
```yaml
custom_providers:
  - name: agnes
    base_url: https://apihub.agnes-ai.com/v1/chat/completions
    api_key: sk-...
    api_mode: chat_completions
    model: agnes-2.0-flash     # ← single model
```

**New (multi-model, preferred):**
```yaml
custom_providers:
  - name: agnes
    base_url: https://apihub.agnes-ai.com/v1/chat/completions
    key_env: AGNES_API_KEY      # ← reads from .env instead of inline
    api_mode: chat_completions
    models:                     # ← dict of all available models
      agnes-2.0-flash:
        context_length: 256000
      agnes-1.5-flash:
        context_length: 256000
```

**Benefits of migrating:**
- `/model` selection menu shows all models instead of just one
- User can switch mid-session with `/model custom:agnes:agnes-1.5-flash`
- When a model is deprecated, add the new name alongside the old one — no downtime

**Common error during migration:** If the config still has `model:` (singular) alongside `models:` (dict), Hermes ignores `models:`. Remove the old `model:` field entirely.

## Non-Chat APIs (Image Gen, TTS, Embeddings)

Custom providers often expose OpenAI-compatible non-chat APIs (image generation, TTS, embeddings, STT) **beyond chat completions**. However, Hermes built-in tools (`image_generate`, `tts`, etc.) only support a fixed set of plugin-registered backends — custom providers registered as `api_mode: chat_completions` are **not** automatically available.

**Workaround:** Write a shell script that calls the provider's API directly via curl, using the same API key and OpenAI-compatible body format.

See `references/custom-provider-non-chat-apis.md` for a worked example (Agnes image generation), the full list of supported `image_gen` backends, and the general pattern for extending this to TTS/embeddings/STT.

## Groq (Worked Example)

**CRITICAL: Groq is NOT a built-in Hermes provider** (issue #58603 open). It must be configured as a **named custom provider** AND `model.provider` must point to `custom:groq`.

**Endpoint:** `https://api.groq.com/openai/v1`
**Models:** `llama-3.3-70b-versatile`, `mixtral-8x7b-32768`, `deepseek-r1-distill-llama-70b`, `gemma2-9b-it`
**Free tier:** Available with registration at console.groq.com

**Two possible setups:**

### Option A: Single custom endpoint (simplest, one model)
```yaml
model:
  default: llama-3.3-70b-versatile
  provider: custom
  base_url: https://api.groq.com/openai/v1
  api_key: gsk_<your-groq-key>
```

### Option B: Named custom provider (multiple models, switchable via /model)
```yaml
custom_providers:
  - name: groq
    base_url: https://api.groq.com/openai/v1
    key_env: GROQ_API_KEY
    models:
      llama-3.3-70b-versatile:
        context_length: 131072
      mixtral-8x7b-32768:
        context_length: 32768
      deepseek-r1-distill-llama-70b:
        context_length: 131072
      gemma2-9b-it:
        context_length: 8192

model:
  default: llama-3.3-70b-versatile
  provider: custom:groq    # ← MUST point to custom:groq, NOT just "custom"
```

**STT (voice-to-text) also supported** — separate from the chat model:
```yaml
stt:
  enabled: true
  provider: groq
```
Set `GROQ_API_KEY` in `.env` when using STT.

**⚠️ Common pitfall:** Defining `custom_providers` with a `name: groq` entry is NOT enough. If `model.provider` is NOT set to `custom:groq`, the provider is UNREGISTERED and will fail with "Unknown provider 'groq'". Always verify both sides match (see Verification Checklist above).

**⚠️ CRITICAL (2026-07-13):** ALL references to the custom provider in config.yaml must use `custom:<name>` syntax, not bare `<name>`. This includes:
- `model.provider` 
- `moa.reference_models[].provider`
- `moa.aggregator.provider`
- `auxiliary.vision.provider` (if applicable)
- Any other section that references a provider

If ANY section uses bare `provider: groq` instead of `provider: custom:groq`, Hermes will fail with "Unknown provider 'groq'" because bare `groq` is NOT a built-in provider. **Audit all config sections** that reference the provider — don't just check `model.provider`.

## Auxiliary Vision Config

Hermes uses `auxiliary.vision` for the vision tool (image analysis). This is a **separate config path** from the `model:` provider — it has its own provider, base_url, and API key.

### Config structure

```yaml
auxiliary:
  vision:
    provider: nvidia              # or openai, anthropic, custom:<name>
    model: meta/llama-3.2-90b-vision-instruct
    base_url: https://integrate.api.nvidia.com/v1
    api_key: nvapi-...            # inline; less secure
    timeout: 120
    download_timeout: 30
```

### Best practices

- **Prefer `key_env` + `base_url_env`** over inline `api_key` + `base_url`, matching the `custom_providers` pattern:

```yaml
auxiliary:
  vision:
    provider: nvidia
    model: meta/llama-3.2-90b-vision-instruct
    base_url_env: NVIDIA_BASE_URL
    key_env: NVIDIA_API_KEY
    timeout: 120
```

### ⚠️ Config conflict: empty top-level `vision:` block

Hermes may auto-generate an empty top-level `vision:` block in `config.yaml`:

```yaml
vision:
  base_url: ''
  model: ''
  provider: ''
```

**This empty block can override `auxiliary.vision`**, causing the vision tool to send requests **without any Authorization header** → HTTP 401 `Missing Authentication Header`.

**Fix:** Delete the empty top-level `vision:` block, or migrate to `key_env`/`base_url_env` (see `references/vision-config-troubleshooting.md` for step-by-step).

## Config File Hierarchy in Profile Mode

⚠️ **Critical:** When Hermes runs under a profile, up to 3 config files can exist, but only ONE is read at runtime. The vision 401 in session 2026-07-13 was directly caused by this disconnect.

| Priority | File | `hermes config path` | custom_providers loaded? | cron/memory/aux loaded? |
|----------|------|---------------------|----------------------|------------------------|
| **1 (active)** | `/opt/data/config.yaml` | ✅ Returns this path | ✅ **Must be here** | ✅ |
| **2 (profile)** | `/opt/data/profiles/<name>/config.yaml` | ❌ | ❌ | ✅ (partial — per-platform tool configs) |
| **3 (legacy)** | `/opt/data/.hermes/config.yaml` | ❌ | ❌ | ✅ (cron, memory, plugins, auxiliary compression) |

**⚠️ CRITICAL NUANCE (2026-07-13):** `.hermes/config.yaml` is NOT "stale" — it is **selectively loaded**. Cron schedules, memory backends, plugin settings, and auxiliary compression configs from `.hermes/config.yaml` **do take effect**. But `custom_providers:` defined there are **invisible to the gateway's model selector**. The gateway resolves custom providers from the ACTIVE config only (`hermes config path`). This leads to a **bait-and-switch** failure mode:
- You add `custom_providers:` entries to `.hermes/config.yaml` and verify them with `python3 -c "from hermes_cli.config import load_config; ..."`
- `load_config()` succeeds and shows your providers
- You run `/restart` expecting them to appear
- `/model` still doesn't show them — because the gateway reads a different file

**Always use `hermes config path` to identify the file that actually controls the running gateway.**

**Always check the active path first:**
```bash
hermes config path    # → tells you which file matters
```

**How settings get orphaned:** A "correct-looking" profile config (`profiles/default/config.yaml` with 709 lines, full `auxiliary.vision` settings) is invisible if the active config is a minimal 41-line version. The running Hermes can't see settings it doesn't know exist.

**Safe fix:** Use `hermes config set` — it writes to the ACTIVE config. See `references/config-hierarchy.md` for the 3-file comparison command and full recovery workflow.

## Docker / No-CLI Environment

When the `hermes` binary is unavailable (e.g., in a Docker container without CLI in PATH):

1. **Edit config.yaml directly** — all provider configuration happens there
2. **No `.env` file?** — inline `api_key` in config.yaml, or create `.env` at `$HERMES_HOME/.env`
3. **Verify after editing** — restart the gateway process or start a new session

## Profile Isolation Gotcha

**CRITICAL: `hermes config show` reads the ACTIVE profile's runtime config, NOT the file on disk.**

- Default profile: `hermes config show` → reads `/opt/data/.hermes/config.yaml`
- Research profile: `hermes config show --profile research` → reads `/opt/data/.hermes/profiles/research/config.yaml`

If a profile directory exists but has NO `config.yaml` or `.env`, it inherits from the default profile. This can cause confusion when you think a profile is "blank" but it's actually using default settings.

**Always verify both profiles explicitly:**
```bash
hermes config show 2>&1 | grep -A5 "Model:"
hermes config show --profile research 2>&1 | grep -A5 "Model:"
```

**Key propagation between profiles:**
- Copy `.env` from source to target: `cp /opt/data/.env /opt/data/.hermes/profiles/research/.env`
- Set model/provider per profile: `hermes config set --profile <name> model.default <model>`
- Built-in plugins (opencode, groq, nvidia) read env vars automatically — no `custom_providers` entry needed

```bash
# Example: creating .env and reading custom_providers key_env
echo "GROQ_API_KEY=gsk_<key>" >> ~/.hermes/.env
```

## Pitfalls

- **EMPTY LIST FALLBACK TRAP (2026-07-13):** `hermes config set fallback_providers.0.xxx` fails with `IndexError: list index out of range` when `fallback_providers: []` is empty. The CLI cannot append to an empty list. **Fix:** use Python + PyYAML to edit `config.yaml` directly — load the YAML, append to the list, dump back. Never rely on `hermes config set` for list indices when the list is empty.
- **UNREGISTERED PROVIDER TRAP:** If `hermes config show` reports `provider: custom:<name>` but `<name>` is NOT listed in the `custom_providers:` YAML section, the provider will fail silently with auth errors. Always verify both sides match (see Verification Checklist above). This caused cascading gateway failures on 2026-07-13.
- **Bare `provider: custom` gets remapped** on some Hermes versions to `opencode-zen`, causing confusing 401 errors. Always use `custom:<name>` syntax with named custom providers when defined.
- **Context length minimum** — Hermes enforces 64K minimum for agent use. Set `context_length` explicitly for Ollama / locally-hosted models (they often default to 4K).
- **`model.base_url` only honored with `provider: custom`** — setting base_url under a built-in provider (e.g. `provider: openrouter`) is silently ignored.
- **key_env vs inline api_key** — `key_env` reads from process environment at startup; changes after the process starts won't take effect. `api_key` in config.yaml is read once at import time; the process must restart for changes.
- **Secrets in config.yaml** — `api_key` in plain text is convenient but less secure than `key_env` + `.env`. Choose based on your threat model (single-user RPi4 is different from multi-tenant deployment).
- **Deprecated `providers.custom:` format** — Do NOT use the old `providers:\\n  custom:\\n    base_url: ...` YAML format. Use the `custom_providers:` list instead. The old format was documented in `references/agnes-provider.md` and is now obsolete.
- **`.hermes/config.yaml` SELECTIVE-LOAD TRAP (2026-07-13):** Adding `custom_providers:` entries to `.hermes/config.yaml` works in `load_config()` tests but is **invisible to the gateway's model selector**. The gateway reads only the file at `hermes config path` for provider registration. `.hermes/config.yaml` is loaded by the cron scheduler, memory subsystem, and plugins — it's NOT stale, just **partitioned**. To make a custom provider appear in `/model`, add it to the ACTIVE config (the one at `hermes config path`). (`base_url: ''`, `model: ''`, `provider: ''`) can override `auxiliary.vision` and cause HTTP 401 `Missing Authentication Header`. The request goes out **without any Authorization header** even though the key is valid. Delete the empty block or migrate `auxiliary.vision` to use `key_env`/`base_url_env`. See `references/vision-config-troubleshooting.md`.
- **DASHBOARD KEY ≠ ENVIRONMENT KEY:** Entering an API key in the Hermes dashboard only sets it in the gateway process environment. Cron jobs, memory scanners, and other background tasks run in isolated sessions that DO NOT inherit the gateway's env vars. **Always set API keys in `.env`** (`/opt/data/.env`) for them to be available everywhere. Dashboard is for interactive use only; `.env` is for persistence across all sessions.
- **MINIMAL TARGETED FIXES:** When the user asks "為何要改這樣" or "直接加在後面嗎", they expect the **single smallest change** — one line, not a refactor. Change `provider: groq` to `provider: custom:groq`, done. Don't also convert to `key_env`, reorganize sections, or add migration steps. Keep scope tight.
- **CONSISTENCY BETWEEN PROVIDERS:** Users notice and call out when custom providers use different patterns. If Agnes uses `custom:agnes`, Groq must also use `custom:groq` — not bare `groq`. Apply the same pattern to all custom providers: `custom:<name>` everywhere.
- **`hermes config set` IS SLOW ON RPi (5–15s per command):** On Raspberry Pi 4, each `hermes config set` can take 5–15 seconds to complete. The CLI is doing config validation, file parsing, and atomic rewriting — this is normal, not hung. Do NOT interrupt it (Ctrl+C can leave partially-written config). For batch operations, chain with `&&` to reduce total wall-clock time. When the output shows a truncated key (`nvap...QH_o`) it is NOT actually truncated — the key is stored in full; Hermes redacts the middle for display.
