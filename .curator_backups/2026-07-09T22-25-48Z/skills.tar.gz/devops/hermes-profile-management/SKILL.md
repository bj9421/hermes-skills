---
name: hermes-profile-management
description: Manage multiple isolated Hermes Agent profiles for different workflows.
---

# Hermes Profile Management

Manage multiple isolated Hermes Agent profiles for different workflows (e.g., research, coding, testing). Each profile has its own config, `.env`, SOUL.md, skills, and cron jobs.

## When to Use
- You need separate environments with different API keys, models, or personas.
- You want to run multiple agents simultaneously without interference.
- You wish to experiment with a new configuration while keeping a stable default.

## Steps

### 1. List Existing Profiles
```bash
hermes profile list
```
Shows current profiles, their models, gateway status, and aliases.

### 2. Create a New Profile (Clone from Default or Another)
```bash
# Clone from the active profile (default if none set)
hermes profile create <profile-name> --clone

# To clone from a specific existing profile:
hermes profile create <profile-name> --clone-from <source-profile>
```
- `--clone` copies `config.yaml`, `.env`, `SOUL.md`, and skills from the source.
- A wrapper script is created at `~/.local/bin/<profile-name>` (add `~/.local/bin` to your `$PATH` for easy use).

### 3. Use a Profile
#### Direct Wrapper (if `$PATH` includes `~/.local/bin`)
```bash
<profile-name> chat          # start interactive chat
<profile-name> dashboard     # start the web dashboard
<profile-name> cron list     # view cron jobs for this profile
```
#### Explicit Profile Flag
```bash
hermes --profile <profile-name> chat
hermes --profile <profile-name> config show
```

### 4. Switch Default (Sticky) Profile
```bash
hermes profile use <profile-name>
```
After this, plain `hermes <command>` uses `<profile-name>` until changed.

### 5. Edit Profile Configuration
#### Edit config.yaml
```bash
hermes --profile <profile-name> config edit
```
#### Edit .env (API keys, model overrides)
```bash
hermes --profile <profile-name> config edit   # .env is edited via the same command
```
> **Note**: The `.env` file is secret‑bearing; the editor will open it but content is not displayed in tool outputs.

### 6. Customize SOUL.md (Persona / Instructions)
```bash
hermes --profile <profile-name> config edit   # then edit the SOUL.md file under the profile directory
```
Or directly:
```bash
$EDITOR /opt/data/profiles/<profile-name>/SOUL.md
```

### 7. Install / Sync Skills
Skills bundled with Hermes are synced automatically on `hermes update`.  
To add extra skills to a profile:
```bash
hermes --profile <profile-name> skills install <skill-name>
```
To view installed skills:
```bash
hermes --profile <profile-name> skills list
```

### 8. Delete a Profile (When No Longer Needed)
```bash
hermes profile delete <profile-name>
```
This removes the profile directory and its wrapper script.  
**Warning**: This action cannot be undone.

## Pitfalls & Troubleshooting
- **Wrapper not found**: Ensure `~/.local/bin` is in your `$PATH`. Add `export PATH="$HOME/.local/bin:$PATH"` to your shell rc file.
- **Multi‑gateway processes are normal**: Each profile with a gateway (default, research, coder) runs its own `hermes gateway run` process. `ps aux | grep hermes` will show multiple gateway PIDs — this is correct, not a leak.
- **Profiles may live outside `~/.hermes/profiles/`**: `hermes profile list` only shows Hermes-managed profiles under `~/.hermes/profiles/`. Legacy or manually-created profiles can exist elsewhere (e.g., `/opt/data/profiles/`), invisible to the CLI until referenced by path. To discover ALL Hermes profile directories on disk:
  ```bash
  find /opt/data -name "profile.yaml" -not -path "*/skills/*" -not -path "*/.hermes/skills/*"
  ```
  Each result is a valid standalone profile directory with its own `config.yaml`, `SOUL.md`, `.env`, and `skills/`. Note the path and decide whether to keep, migrate, or delete.
- **Dashboard "API" light vs gateways**: The "API" indicator on the dashboard lights up for `hermes serve`, NOT for profile gateways. An absent API light is normal in Telegram-only workflows. See `hermes-dashboard-troubleshooting` skill → `references/service-topology.md`.
- **Dashboard binds only to localhost**: By default the dashboard refuses to bind to `0.0.0.0` unless an auth provider is configured or `--insecure` is set. For external access (e.g., via Tailscale) set:
  ```bash
  export HERMES_DASHBOARD_INSECURE=1   # only on trusted networks
  export HERMES_DASHBOARD_PORT=8501
  export HERMES_DASHBOARD_HOST=0.0.0.0
  ```
  Then restart the dashboard service (`hermes dashboard --stop` then `hermes dashboard`).
- **Environment variables not persisting**: Variables set in the shell do not affect the supervised dashboard service. To make them permanent, edit the profile’s `.env` or configure via `hermes config set` inside the profile.
- **Cloning from wrong source**: Verify the source profile with `hermes profile list` before using `--clone-from`.
- **Forgot to reload after SOUL.md changes**: Restart the chat session or run `hermes profile use <name>` again to pick up updates.
- **Memory isolation despite sharing config.yaml**: A profile with a `config.yaml` that lacks an explicit `plugins.hermes-memory-store.db_path` may silently use a separate SQLite DB in `$HOME/.hermes/` under that profile's runtime, NOT the root config's `db_path`. Always set `db_path` explicitly — and use an **absolute path**— in every profile's config to avoid this. Verify with `find /opt/data -name "memory_store.db" -not -path "*/state/*"`.
- **Export scripts break after memory consolidation**: After merging two profiles' memory stores, any export or pipeline scripts that read from the old per-profile DB paths will silently produce stale/empty output. Always update the DB path in those scripts and run a test export after consolidation. See `references/memory-to-obsidian-export.md` for the common memory→Obsidian pipeline pattern.

## Verification
After creating a profile, confirm isolation:
```bash
# Check that .env differs
diff /opt/data/.hermes/.env /opt/data/profiles/<profile-name>/.env

# Ensure skills directory is separate
ls /opt/data/profiles/<profile-name>/skills/
```

## References
- See `hermes profile --help` for all subcommands.
- For dashboard external access troubleshooting, refer to the skill `hermes-dashboard-troubleshooting` (if available) or the Hermes docs on `HERMES_DASHBOARD_INSECURE`.
- For deep-dive on per-profile memory architecture, sharing strategies, and holographic provider settings: `references/memory-architecture.md`.
- For the automated memory-to-Obsidian export pipeline (no_agent cron, vault permission strategy, export script patterns): `references/memory-to-obsidian-export.md`.
- For discovering profiles that exist outside the official `~/.hermes/profiles/` directory (legacy/migrated/manually created): `references/profile-discovery.md`.
