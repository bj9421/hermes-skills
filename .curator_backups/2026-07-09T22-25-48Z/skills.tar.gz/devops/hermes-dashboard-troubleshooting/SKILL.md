---
name: hermes-dashboard-troubleshooting
category: devops
description: Troubleshoot Hermes dashboard connectivity and service issues.
---

# Hermes Dashboard Troubleshooting

## Trigger Conditions
- Hermes dashboard is unreachable via browser or curl.
- Port mapping errors when trying to access dashboard on expected host port.
- Dashboard service appears to be down or not starting in s6 supervision.
- Environment variable misconfiguration (HERMES_DASHBOARD, HERMES_DASHBOARD_PORT, HERMES_DASHBOARD_HOST).
- Using Tailscale or other VPN and unable to reach dashboard.

## Step‑by‑Step Procedure

### 1. Verify Dashboard Enable Flag
Check that `HERMES_DASHBOARD` is set to a truthy value (1, true, yes, etc.).  
If the flag is falsy or unset, the s6 service will exit immediately and report permanent failure.

```bash
# Inside the container or host env
echo $HERMES_DASHBOARD
```

### 2. Confirm Port and Host Settings
Ensure the following variables are set as desired:
- `HERMES_DASHBOARD_PORT` (default 9119)
- `HERMES_DASHBOARD_HOST` (default 0.0.0.0)

```bash
echo $HERMES_DASHBOARD_PORT
echo $HERMES_DASHBOARD_HOST
```

### 3. Inspect s6 Service Status
List s6 services to see if the dashboard service is down or in a permanent‑failure state.

```bash
# On the host (if you have s6 utilities) or inside container:
s6-svstat /run/service/dashboard
```

Look for `down` or `paused` status. If the service shows `permanent failure`, the enable flag is likely falsy.

### 4. Restart the Dashboard Service
After correcting environment variables, request s6 to restart the service.

```bash
# Trigger a restart (sends TERM then CONT)
s6-svc -t /run/service/dashboard
# Or force a restart if needed
s6-svc -r /run/service/dashboard
```

### 5. Verify the Process Is Running
Check that the `hermes dashboard` process is up and listening on the intended port.

```bash
ps aux | grep "hermes dashboard" | grep -v grep
```

### 6. Confirm Port Binding
Use available tools to see if the process is bound to the expected interface and port.

```bash
# If netstat or ss is available:
netstat -tlnp | grep :$HERMES_DASHBOARD_PORT
ss -tlnp | grep :$HERMES_DASHBOARD_PORT
```

If neither tool is installed, you can check `/proc/net/tcp` or attempt a curl.

### 7. Test Connectivity
From the host or another machine on the same network (including via Tailscale), try to reach the dashboard.

```bash
curl http://<host_ip>:$HERMES_DASHBOARD_PORT
# Should return HTML or a redirect to the login page.
```

If using Tailscale, ensure the Tailscale IP is reachable and firewall rules allow the port.

### 8. Check Logs for Errors
If the service repeatedly fails, inspect the dashboard log (if enabled) or the container’s stdout/stderr.

```bash
# Example log location (may vary)
cat /tmp/dashboard.log 2>/dev/null || echo "Log not found"
```

### 9. Common Pitfalls
- **Forgotten enable flag**: Setting only the port without `HERMES_DASHBOARD=1` leaves the service disabled.
- **Assuming hot‑reload**: Changing environment variables does not affect a already‑running dashboard; you must restart the s6 service.
- **Permission denied on `/run/s6/container_environment`**: This directory is owned by root; the hermes user cannot write to it directly. Use s6‑provided mechanisms or restart the container with correct env.
- **Conflicting port mappings**: Ensure the host‑to‑container port mapping matches `HERMES_DASHBOARD_PORT` (e.g., `-p 8501:8501` if you set the internal port to 8501).
- **Tailscale subnet routes**: Verify that the Tailscale interface is up and that the advertised subnet includes the host’s port.

### 10. Verification Checklist
- [ ] `HERMES_DASHBOARD` is set to a truthy value.
- [ ] `HERMES_DASHBOARD_PORT` matches the host‑side port in `-p HOST:CONTAINER`.
- [ ] `s6-svstat /run/service/dashboard` shows `up` (pID and timeout).
- [ ] `ps` shows `hermes dashboard --host ... --port ...` running.
- [ ] Port is listening on `0.0.0.0` (or the specified host) and the correct port number.
- [ ] `curl http://<host>:$HERMES_DASHBOARD_PORT` returns a successful HTTP response (200).
- [ ] If using Tailscale, `tailscale ip -4` shows an address reachable from the client, and the same curl works via that IP.

## References
- Hermes Dashboard documentation: https://hermes-agent.nousresearch.com/docs/dashboard/
- s6-overlay service management: https://skarnet.org/software/s6-overlay/
- Environment variable precedence in Hermes containers: values in `/run/s6/container_environment` override Docker `-e` at service start time.
- **Dashboard status indicators & service topology**: `references/service-topology.md` — explains what each green light means, which services are expected in different configurations, and when a missing "API" light is normal.

## Templates
- `templates/dashboard-env.example`: Example snippet for docker‑run or compose file.

## Scripts
- `scripts/check_dashboard.sh`: One‑liner to verify dashboard status (optional).