# Cron Jobs Structure Reference

## Jobs File Location

Cron jobs are stored per-profile at:
```
/opt/data/profiles/<profile>/cron/jobs.json
```

## File Structure

The `jobs.json` is a **dict** with a `jobs` key containing a list of job objects:

```json
{
  "jobs": [
    {
      "id": "e5f9e642f5c4",
      "name": "Job Display Name",
      "prompt": "Detailed instructions for the agent...",
      "schedule": {
        "kind": "cron",
        "expr": "0 22 * * *"
      },
      "enabled": true,
      "state": "running",
      ...
    }
  ]
}
```

**Key fields:**
| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique job identifier |
| `name` | string | Display name |
| `prompt` | string | Instructions sent to agent on each run |
| `schedule.kind` | string | Usually `"cron"` |
| `schedule.expr` | string | 5-field cron expression |
| `enabled` | bool | Whether job is active |
| `state` | string | `"running"`, `"paused"`, `"completed"` |

**Parsing tip:** The top-level is a dict, NOT a list. Always access via `data.get("jobs", [])`.

## Profile-Specific Notes

- **default profile:** `cron/` directory exists but is empty (no jobs configured).
- **research profile:** Contains all data pipeline and sync cron jobs.

## Common Jobs in Research Profile

| Name | Schedule | Enabled | Purpose |
|------|----------|---------|---------|
| 補完股票缺漏資料 | `0 18 * * 1-5` | ✓ | Fill missing TWSE stock data |
| taiwan-tech-strategy-daily | `0 16 * * *` | ✓ | Daily tech indicator update |
| finmind-batch-financial-update | `0 15 * * *` | ✓ | Financial data batch fetch |
| holographic-to-obsidian-sync | `0 2 * * *` | ✓ | Export memory to markdown |
| ohlc-verification | `0 16 * * 1-5` | ✓ | OHLC cross-verification |
| ohlc-verification-full | `0 2 * * 6` | ✓ | Weekly full OHLC verification |
| IG 台灣景點每日熱門排行 | `0 22 * * *` | ✗ | Instagram hot spots (paused) |
| twstock-catchup | `0 15 * * 1-5` | ✗ | Stock catch-up (paused) |
| taiwan-stock-api-watchdog | ? | ✗ | Port 5000 watchdog (paused) |
