---
name: legacy-script-cleanup
description: >-
  Systematic process to identify, classify, and safely remove
  obsolete test scripts, duplicate iterations, and abandoned
  API comparison files from project directories.
version: 1.0.0
author: Hermes Agent
tags: [cleanup, scripts, legacy, maintenance, organization]
---

# Legacy Script Cleanup

## When to Use

- Scripts directory has accumulated test files (test_*.py, compare_*.py)
- Multiple versions of the same tool exist (fix_incomplete_v1.py → v5.py)
- Unclear which scripts are actively used vs experimentally abandoned
- Before merging or consolidating project directories

## Step-by-Step Procedure

### 1. Inventory All Files

```bash
ls -lh /opt/data/scripts/
```

### 2. Check Cron References

```python
import json, os, glob

all_prompts = []
for path in glob.glob('/opt/data/profiles/*/cron/jobs.json') + ['/opt/data/cron/jobs.json']:
    if os.path.exists(path):
        with open(path) as f:
            data = json.load(f)
            for j in data.get('jobs', []):
                prompt = j.get('prompt', '') or ''
                all_prompts.append((j.get('name',''), prompt))

referenced = set()
for fname in os.listdir(target_dir):
    for name, prompt in all_prompts:
        if fname in prompt:
            referenced.add(fname)
```

### 3. Classify Files

| Category | Pattern | Action |
|----------|---------|--------|
| **Keep** | Referenced by cron | ✅ Retain |
| **Keep** | Latest version in series (e.g., fix_incomplete_v3.py) | ✅ Retain |
| **Delete** | Old versions (v1, v2, v4...) | ❌ Remove |
| **Delete** | Same-night test files (test_twse_*.py, test_tpex_*.py) | ❌ Remove |
| **Delete** | Comparison/report scripts (compare_*.py, final_*.py) | ❌ Remove |
| **Delete** | One-time manual scripts (manual_update_*.py) | ❌ Remove |
| **Review** | Root-level .py not in cron | ⚠️ Check individually |

### 4. Safe Deletion Pattern

```bash
# API comparison tests (all from same night)
rm scripts/test_twse_*.py scripts/test_tpex_*.py scripts/test_finmind_*.py scripts/test_tdcc_*.py

# Old iterations
rm scripts/fix_incomplete_{dates,fast,parallel,targeted,v4}.py

# One-time scripts
rm scripts/manual_update_*.py scripts/incremental_update*.py
```

### 5. Verify Post-Cleanup

```bash
# Re-check cron references haven't broken
python3 scripts/fix_incomplete_v3.py --dry-run
```

## Common Patterns

### API Source Comparison Sessions
Users often run a batch of API tests comparing multiple data sources (TWSE, TPEX, FinMind, TDCC). This produces:
- `test_<source>_<feature>.py` files (gzip, brotli, csrf, openapi, redirect...)
- `compare_*.py` and `final_*.py` reports
- `rate_limit_test.py`
- **All are disposable after the comparison is done.**

### Iterative Script Development
When debugging a script, users create multiple versions:
- `fix_incomplete_dates.py` → `fix_incomplete_fast.py` → `fix_incomplete_parallel.py` → `fix_incomplete_targeted.py` → `fix_incomplete_v3.py` → `fix_incomplete_v4.py`
- **Keep only the latest version that's in use.**

### Root-Level Scripts
Files in `/opt/data/*.py` are often:
- One-time utilities (fetch_stocks.py, test_twse.py)
- Dashboard components (dashboard.py, render_heatmap.py)
- **Check if referenced by cron before deleting.**

## Pitfalls

1. **Don't delete wrapper scripts** — `run_daily_incremental_update.sh` calls other scripts and may not be directly named in cron prompts.
2. **Check shebang lines** — Some scripts may be invoked indirectly via `python3 script.py` in cron prompts that don't include the filename literally.
3. **Preserve the latest version** — When cleaning iterative development, always keep the newest numbered/lettered version.
4. **Archive before merge** — Before consolidating directories, rename (not delete) to preserve history.

## Related Skills

- `taiwan-stock-data-pipeline` — Has accumulated many legacy scripts from API comparisons
- `git-worktrees` — For safe experimentation without polluting main workspace
- `writing-plans` — Structured development prevents legacy accumulation

## Scripts

- `scripts/legacy_script_cleaner.py` — Automated scanner that checks cron references and classifies files. Usage: `python3 legacy_script_cleaner.py` (report mode) or `python3 legacy_script_cleaner.py --delete test_twse_*.py` (delete mode)
