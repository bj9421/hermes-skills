---
name: kanban
description: "File-based Kanban board for Hermes Agent. Track tasks across Backlog → Todo → Doing → Review → Done with persistent JSON storage and markdown exports."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kanban, project-management, workflow, tracking, productivity]
    related_skills:
      - ha-powers
      - writing-plans
      - subagent-driven-development
      - requesting-code-review
---

# 📋 Kanban — File-Based Board

> **Zero-dependency Kanban for Hermes.** Cards stored in `KANBAN.json` in your project root. Works with any project, integrates into the ha-powers pipeline.

## Quick Start

```bash
# 1. Init a board in your project
kanban init --board "My Project"

# 2. Add cards
kanban add "Implement login page" --col todo --prio P1 --desc "OAuth + email login"
kanban add "Fix navbar z-index" --col todo --prio P3

# 3. Start working
kanban move K1 --col doing

# 4. See the board
kanban list

# 5. Mark done
kanban move K1 --col review
kanban move K1 --col done

# 6. Export pretty markdown (→ Obsidian)
kanban board --output kanban/KANBAN.md
```

## Commands

| Command | What it does | Example |
|---------|-------------|---------|
| `init` | Create a new board | `kanban init --board "HA-POWERS"` |
| `add` | Add card to Backlog (or `--col`) | `kanban add "Fix bug" --prio P1 --desc "..."` |
| `move` | Move card between columns | `kanban move K1 --col doing` |
| `list` / `ls` | Show the board | `kanban list --col review` |
| `info` | Card details + activity log | `kanban info K1` |
| `log` | Add a note to card history | `kanban log K1 "Reviewed by architect"` |
| `edit` | Change title/desc/priority/assignee | `kanban edit K1 --prio P1 --assign @xun` |
| `board` | Export to Markdown (Obsidian-ready) | `kanban board --output docs/board.md` |
| `archive` | Archive Done cards older than N days | `kanban archive --days 7` (default: 7) |

## Columns

```
📋 Backlog  ─→  📝 Todo  ─→  🚧 Doing  ─→  🔍 Review  ─→  ✅ Done
  (icebox)      (planned)     (in prog)     (QC gate)      (finished)
```

The move command accepts **partial column names** (e.g. `--col todo`, `--col do`, `--col rev`).

## Priority Levels

| Level | Meaning |
|-------|---------|
| 🔴 P0 | Critical — blocker, fire |
| 🟠 P1 | High — next sprint |
| 🟡 P2 | Medium — normal priority |
| 🟢 P3 | Low — nice to have |
| ⚪ P4 | Backlog — maybe someday |

## Card Data Model

Each card stores:
- **ID** — auto-assigned: `K1`, `K2`, ...
- **Title** — what you see on the board
- **Column** — which stage it's in
- **Priority** — P0–P4
- **Assignee** — optional `@user`
- **Description** — free-text details
- **Subtasks** — optional checklist (auto-created from writing-plans)
- **Timestamps** — created, moved, logged
- **Activity Log** — every move + manual entries

## Integration with ha-powers

> The kanban skill is **embedded into ha-powers Phase 4**. Each task dispatched to a Developer subagent is automatically tracked.

### Auto-tracking Flow

```
Phase 4 starts:
  kanban add "Task 1: User model" --col doing --prio P1

Developer subagent dispatched:
  kanban log K1 "Dispatched to Developer A"

Spec review done:
  kanban log K1 "Spec review: PASS"

Quality review done:
  kanban log K1 "Quality review: APPROVED"

Task complete:
  kanban move K1 --col review

All tasks done:
  (orchestrator moves each to done)
```

### When ha-powers auto-creates cards

When you run ha-powers and it parses a plan with N tasks, it automatically:

```bash
kanban add "Task 1: User model" --col todo
kanban add "Task 3: Auth middleware" --col todo
kanban add "Task 5: Test fixtures" --col todo
```

And when dispatching:

```bash
kanban move K1 --col doing
kanban log K1 "🔄 Dispatched to Developer A"
```

### When reviewing:

```bash
kanban move K1 --col review
kanban log K1 "🔍 Spec review in progress..."
kanban log K1 "🔍 Quality review in progress..."
kanban log K1 "✅ All reviews passed!"
kanban move K1 --col done
```

## Standalone Usage (without ha-powers)

Kanban works as a standalone tool for any project:

```bash
cd my-project
kanban init --board "Sprint 1"
kanban add "Research auth libraries" --prio P2 --desc "Compare passport, auth0, supabase"
kanban add "Set up CI/CD" --prio P1

# Daily check-in
kanban list
kanban move K1 --col doing

# End of sprint
kanban archive --days 1
kanban board --output docs/sprint1-retro.md
```

## Path Options

All commands accept `--path <dir>` to operate on a board in a different directory:

```bash
kanban --path /opt/data/projects/my-app list
kanban --path ~/obsidian-vault/Projects/HAPower add "Fix bug" --col todo
```

## File Format

Data is stored in `KANBAN.json` (plain JSON, git-friendly):
```json
{
  "board": "My Project",
  "columns": ["Backlog", "Todo", "Doing", "Review", "Done"],
  "cards": [
    {
      "id": "K1",
      "title": "Rate limiter middleware",
      "column": "Doing",
      "priority": "P1",
      "assignee": "xun",
      "desc": "IP-based rate limiting with Redis",
      "subtasks": [
        {"id": "S1", "title": "Design interface", "done": true},
        {"id": "S2", "title": "Implement middleware", "done": false},
        {"id": "S3", "title": "Write tests", "done": false}
      ],
      "created_at": "2026-07-08T03:30:00Z",
      "logs": [
        {"timestamp": "2026-07-08T03:31:00Z", "message": "Moved from Todo → Doing"},
        {"timestamp": "2026-07-08T03:35:00Z", "message": "Dispatched to Developer A"}
      ]
    }
  ],
  "next_id": 2,
  "created_at": "2026-07-08T03:00:00Z",
  "updated_at": "2026-07-08T03:35:00Z"
}
```

### Subtask Tracking

When a card is created from a writing-plans output, subtasks are auto-populated:

```bash
# Auto-create subtasks from plan
kanban add "Task 1: User model" --col todo --subtasks "Design interface,Implement model,Write tests"

# Or manually
kanban subtask add K1 "Test fixtures"
kanban subtask move K1 S1 --done
kanban subtask list K1
```

Subtask status:
- `[ ]` pending
- `[x]` done
- `[>]` in progress

Example output:
```
K1: Rate limiter middleware (2/3 done)
├── [x] Design interface
├── [x] Implement middleware
└── [ ] Write tests
```

## Best Practices

- **Init kanban at project start** — before any work begins
- **Move cards as you work** — `kanban move K1 --col doing` when you start a task
- **Log important events** — reviews, decisions, blockers
- **Archive weekly** — keep the board clean, data stays in `archived_cards`
- **Export before demos** — `kanban board --output kanban/board.md` for Obsidian/screenshots
- **Use priority honestly** — not everything can be P1
- **Subtask granularity** — create subtasks only when a card has 3+ clearly independent steps; don't over-split

> 💡 **Kanban vs Progress Tracker:**
> - **Progress Tracker** (inside ha-powers) = tracks one feature's development steps in real-time. Disappears after the feature is done.
> - **Kanban** = tracks multiple features across sessions. Persists in `KANBAN.json`.
> - Use Kanban to decide WHAT to build next; use Progress Tracker to track HOW you build it.

## Manual kanban list Example Output

```
======================================================================
  📋 HA-POWERS Dev
======================================================================

  📋 Backlog (1)
  ──────────────────────────────────────────────────────────────────
    ID    Priority       Title
    ────  ──────────     ─────────────────────────────────────
    K5    ⚪ P4          Nice to have: dark mode toggle

  🚧 Doing (2)
  ──────────────────────────────────────────────────────────────────
    ID    Priority       Title
    ────  ──────────     ─────────────────────────────────────
    K1    🟠 P1          Rate limiter middleware   @xun
    K3    🟡 P2          Redis integration

  ✅ Done (1)
  ──────────────────────────────────────────────────────────────────
    ID    Priority       Title
    ────  ──────────     ─────────────────────────────────────
    K2    🟠 P1          Login page redesign

  Total: 4 cards (4 shown)
```
