---
name: auto-memory-recorder
description: Use when recording facts to memory — automatically tags source (調查/使用者要求/自動偵測), links entities, and maintains knowledge graph structure.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [memory, auto-record, knowledge-graph, entities]
    related_skills: [hermes-agent]
---

# Auto Memory Recorder

## Overview

Automatically records facts to Hermes memory with structured metadata:
- `source` field: tracks where the fact came from
- Entity linking: connects related facts into a knowledge graph
- Trigger detection: responds to "記下來" and session completion events

## Source Classification

Every memory entry MUST include a source tag:

| Source | When to Use | Example |
|--------|-------------|---------|
| `使用者要求` | User explicitly states preference/request | "User prefers concise responses" |
| `自動偵測` | Inferred from session context/errors | "Dashboard uses 24-hour format" |
| `調查` | Result of investigation/research | "Docker PUID mismatch caused sync failure" |

## Entity Linking

Group related facts by entity keywords:
- **Hardware**: RPi, Docker, Syncthing, PUID
- **Software**: Hermes, Obsidian, GitHub, Dashboard
- **Data**: Stock, Taiwan, SQLite, screen_cache
- **Preferences**: Language, format, style

Related facts share the same entity keyword → automatically linked in memory.

## Triggers

### 1. Explicit "記下來"
When user says "記下來" or "remember this":
1. Capture current conversation context
2. Extract key facts
3. Tag with source: `使用者要求`
4. Save to memory immediately

### 2. Task Completion
After complex tasks (5+ tool calls):
1. Scan conversation for new facts
2. Classify source
3. Link entities
4. Save to memory

### 3. Cron Scan
Every 6 hours scan of recent sessions:
1. Extract new facts
2. Merge with existing memory
3. Update source tags

**Pitfall:** Daily cron is too infrequent for active sessions. Use `every 6h` schedule instead — balances freshness with token cost.

## Workflow

1. **Detect** — Identify new fact from conversation/session
2. **Classify** — Determine source (調查/使用者要求/自動偵測)
3. **Link** — Match entity keywords for knowledge graph
4. **Save** — Write to memory with structured format
5. **Verify** — Check memory isn't corrupted

### Cron Auto-Scan Implementation

The auto-scan script lives at `/opt/data/scripts/auto_memory_scan.py`. It:
- Queries `/opt/data/state.db` (NOT `~/.hermes/state.db`) for sessions in the last N hours
- Extracts factual statements from user/assistant messages using keyword heuristics
- Deduplicates across sessions
- Outputs formatted facts with `| source: 自動掃描` tags

**Pitfall:** Cron sessions run in isolated contexts where the `memory` tool is unavailable. The script prints facts as output for delivery instead of saving directly. Always check memory tool availability before attempting to save in cron jobs.

See `references/cron-schedules.md` for recommended cron frequencies.

## Format

```
fact content | source: [調查|使用者要求|自動偵測]
```

## Verification Checklist

- [ ] Source tag present on every new entry
- [ ] Entity keywords match existing facts
- [ ] No duplicate entries
- [ ] Memory size within limits
